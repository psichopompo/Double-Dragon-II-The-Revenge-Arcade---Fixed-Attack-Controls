"""build_v52.py - reconstruye la v52 ENTERA desde la ROM virgen.

Es el constructor unico del proyecto: documenta cada cambio, comprueba
que ningun bloque invade a otro y verifica el MD5 al final.

    python3 tools/build_v52.py [destino/ddragon2.zip]

MAPA DE LA MODIFICACION
=======================

26a9-04.bin (CPU principal, $8000-$FFFF)

  $8B71  STA $43,X       -> JSR $F917   guarda el boton pulsado en +$27
  $8E99  ventana del buffer de combinaciones:  3 -> 4 frames
  $8F2C  STA $1E,X       -> JSR $FBB2   decide la accion por BOTON
  $8F4D  RTS   anula la 1a pasada direccional (sin arma)
  $8F74  RTS   anula la 2a pasada direccional (armas 1 y 4)
  $8F9E  RTS   anula la 3a pasada direccional (armas 2 y 7, LATIGO)
  $8FAF  RTS   anula la 4a pasada direccional (armas 3, 5 y 6)
  $97B2  cabecera nueva del ataque aereo (29 B)
  $97D9  el STB 3,X ya no fuerza el volteo -> JSR $FD18
  $983A  filtro del huracan -> JSR $FDDC

  $F917  gancho 1: +$27 = boton de ataque, o CERO si no hay ninguno
  $F9D0  pares de acciones (codazo/ras, latigo, otras armas, cuchillo)
  $FBB2  gancho 2: clasifica la accion y salta al par correspondiente
  $FCD2  decision del ataque aereo
  $FD18  sustituye al STB 3,X (conserva la orientacion)
  $FDDC  filtro del huracan (solo con el puno y sin arma)

26ac-0e.63 (banco conmutado)

  $C96D/$C971  rama IZQUIERDA de la RECOGIDA: coger con el puno
  $C97A/$C97E  rama DERECHA  de la RECOGIDA: coger con el puno

RESULTADO
=========
  TIERRA         Fire1 = coz            Fire3 = puno
  SALTO+ATAQUE   Fire1 = patada al ras  Fire3 = CODAZO
  CUCHILLO       Fire1 = coz            Fire3 = LANZAR
  LATIGO         Fire1 = giro           Fire3 = golpe normal
  RECOGER        solo con el puno (Fire3)
  EN EL AIRE     Fire1 = patada voladora
                 Fire3 = huracan en la cuspide, y SOLO sin arma
  VENTANA        4 frames para las combinaciones (antes 3)
"""
import hashlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from asm6809 import asm
from build3 import construye3

# OJO: el MD5 del ZIP depende de la compresion, no solo del contenido.
# Lo que se verifica es el MD5 de las ROMs de dentro (norma 479).
MD5_CPU = '3f5f52bd363519ca55b94293e7d58a47'   # 26a9-04.bin parcheado
MD5_BNK = 'ba36cb71f1437b947bab2b50f09234f2'   # 26ac-0e.63 parcheado


def construye(dst='roms/v52/ddragon2.zip', verbose=True):
    # ---- gancho 1: recordar el boton (y borrarlo al soltar) ----
    g1, _ = asm(0xF917, """
            STA  $43,X
            PSHS A
            ANDA #$50
            STA  $27,X
            PULS A
            RTS
    """)

    # ---- gancho 2: clasificar la accion y saltar al par ----
    SRC = """
            PSHS B
            LDB  $27,X
            BEQ  sal
            CMPA #$05
            BEQ  p56
            CMPA #$06
            BEQ  p56
            CMPA #$0E
            BEQ  pEF
            CMPA #$0F
            BEQ  pEF
            CMPA #$10
            BEQ  p10
            CMPA #$11
            BEQ  p10
            CMPA #$0C
            BEQ  parm
            CMPA #$01
            BEQ  amb
            CMPA #$00
            BNE  sal
    amb:    TST  $21,X
            BNE  parm
            LDA  #$00
            BITB #$10
            BEQ  sal
            LDA  #$01
    sal:    PULS B
            STA  $1E,X
            RTS
    p56:    JMP  $F9D0
    pEF:    JMP  $F9DC
    p10:    JMP  $F9E8
    parm:   JMP  $F9F4
    """
    g2, labs = asm(0xFBB2, SRC)
    SAL = labs['sal']

    def par(base, si_puno, si_patada):
        return asm(base, "LDA #$%02X\nBITB #$10\nBEQ f\nLDA #$%02X\nf: JMP $%04X"
                   % (si_puno, si_patada, SAL))[0]

    g3 = par(0xF9D0, 0x05, 0x06)   # codazo (puno) / patada al ras
    g4 = par(0xF9DC, 0x0E, 0x0F)   # latigo: golpe / giro
    g5 = par(0xF9E8, 0x10, 0x11)   # otras armas  [par SIN medir]
    g6 = par(0xF9F4, 0x0C, 0x01)   # cuchillo: lanzar (puno) / coz

    # ---- ataque aereo ----
    aire, _ = asm(0xFCD2, """
            LDA  $43,X
            BITA #$10
            BNE  si
            BITA #$40
            BEQ  no
            TST  $21,X
            BNE  no
            PSHS B
            LDB  $11,X
            CMPB #$05
            BCC  nob
            CMPB #$02
            BCS  nob
            PULS B
    si:     LDA  #$01
            RTS
    nob:    PULS B
    no:     CLRA
            RTS
    """)
    head, _ = asm(0x97B2, "JSR $FCD2\nBNE ataca\nJMP $97E3\nataca: NOP")
    head += bytes([0x12]) * (29 - len(head))
    noflip, _ = asm(0x97D9, "JSR $FD18\nNOP\nNOP")
    rut, _ = asm(0xFD18, "LDA $18,X\nRTS")
    hur, _ = asm(0xFDDC,
                 "LDA $27,X\nBITA #$40\nBEQ nohur\nLDA $21,X\nRTS\nnohur: LDA #$FF\nRTS")

    # ---- comprobaciones de solapamiento (norma 469) ----
    assert 0xFBB2 + len(g2) <= 0xFC00, 'el gancho 2 se sale de su hueco'
    assert 0xFCD2 + len(aire) <= 0xFD00, 'la rutina del aire se sale'
    for base, blk, tope in ((0xF9D0, g3, 0xF9DC), (0xF9DC, g4, 0xF9E8),
                            (0xF9E8, g5, 0xF9F4), (0xF9F4, g6, 0xFA00)):
        assert base + len(blk) <= tope, 'el par de $%04X se sale' % base
    assert len(head) == 29, 'la cabecera del aire debe medir 29 B'
    assert len(noflip) == 5, 'el parche de $97D9 debe medir 5 B'

    return construye3({
        '26a9-04.bin': {
            0x0B71: bytes([0xBD, 0xF9, 0x17]),
            0x0E99: bytes([0x04]),
            0x0F2C: bytes([0xBD, 0xFB, 0xB2]),
            0x0F4D: bytes([0x39]),
            0x0F74: bytes([0x39]),
            0x0F9E: bytes([0x39]),
            0x0FAF: bytes([0x39]),
            0x17B2: head,
            0x17D9: noflip,
            0x183A: bytes([0xBD, 0xFD, 0xDC]),
            0x7917: g1,
            0x7BB2: g2,
            0x79D0: g3, 0x79DC: g4, 0x79E8: g5, 0x79F4: g6,
            0x7CD2: aire,
            0x7D18: rut,
            0x7DDC: hur,
        },
        '26ac-0e.63': {
            0x064BE: bytes([0x40]), 0x064C2: bytes([0x10]),   # recogida, izq
            0x064CB: bytes([0x10]), 0x064CF: bytes([0x40]),   # recogida, der
        },
    }, dst, verbose=verbose)


if __name__ == '__main__':
    dst = sys.argv[1] if len(sys.argv) > 1 else 'roms/v52/ddragon2.zip'
    construye(dst, verbose=False)
    import zipfile
    z = zipfile.ZipFile(dst)
    ok = True
    for n, esp in (('26a9-04.bin', MD5_CPU), ('26ac-0e.63', MD5_BNK)):
        m = hashlib.md5(z.read(n)).hexdigest()
        bien = (m == esp)
        ok &= bien
        print('  %-12s %s  %s' % (n, m, 'OK' if bien else '*** NO COINCIDE ***'))
    print('%s  %s' % (dst, 'VERIFICADO' if ok else 'REVISAR'))
