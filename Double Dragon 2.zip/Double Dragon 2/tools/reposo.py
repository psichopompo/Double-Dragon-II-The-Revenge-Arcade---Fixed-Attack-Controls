"""reposo.py - detecta cuando el personaje esta REALMENTE quieto:
espera a que +$1E, +$02 y la posicion no cambien durante N frames seguidos."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
BASE = 0x3A2

def hasta_reposo(f, maxf=400, estable=20):
    prev, n = None, 0
    for i in range(maxf):
        f.run(1)
        s = f.state()
        cur = (s[BASE+0x1E], s[BASE+2], s[BASE+0x0B], s[BASE+0x0C], s[BASE+0x1B])
        if cur == prev:
            n += 1
            if n >= estable:
                return i
        else:
            n = 0
        prev = cur
    return -1

if __name__ == '__main__':
    zipp, giro, bot = sys.argv[1], sys.argv[2], sys.argv[3]
    f = FBA(zipp); f.run(200)
    f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
    f.press('START',frames=4,after=10); f.run(900)
    f.hold(giro); f.run(8); f.release()
    t = hasta_reposo(f)
    s = f.state()
    print('# reposo tras %d frames  1E=%02X 02=%02X 1B=%02X'
          % (t, s[BASE+0x1E], s[BASE+2], s[BASE+0x1B]))
    out=[]
    for i in range(12):
        f.hold(bot) if i<4 else f.release()
        f.run(1)
        s=f.state()
        out.append('%02X:%02X' % (s[BASE+0x1E], s[BASE+2]))
    print('%-6s %-2s' % (giro,bot), ' '.join(out))
