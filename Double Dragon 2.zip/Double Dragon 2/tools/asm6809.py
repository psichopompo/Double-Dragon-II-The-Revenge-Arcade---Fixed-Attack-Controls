"""asm6809.py - mini-ensamblador 6809 con ETIQUETAS.

Motivo (norma 461): calcular los desplazamientos de las ramas a mano me ha
producido DOS bugs seguidos (rama a la instruccion equivocada y pila
desbalanceada). Con etiquetas eso no puede pasar.

Uso:
    from asm6809 import asm
    code = asm(0xFBB2, '''
        CMPA #$02
        BCC  fin
        ...
    fin: STA  $1E,X
        RTS
    ''')
"""
import re

# (mnemo, modo) -> opcode.  modos: inh, imm, idx8 (offset 8 bits con ,X), rel
OPC = {
 ('EORB','imm'):[0xC8],
 ('COMB','inh'):[0x53], ('COMA','inh'):[0x43], ('NEGB','inh'):[0x50], ('NEGA','inh'):[0x40],
 ('TST','idx'):[0x6D,0x88],
 ('STA','idxs'):[0xA7,0xE4], ('STB','idxs'):[0xE7,0xE4],
 ('CMPB','idxs'):[0xE1,0xE4], ('CMPA','idxs'):[0xA1,0xE4],
 ('LDB','idxs'):[0xE6,0xE4], ('LDA','idxs'):[0xA6,0xE4],
 ('LDU','imm16'):[0xCE], ('LDY','imm16'):[0x10,0x8E], ('LDX','imm16'):[0x8E],
 ('LDB','idxu'):[0xE6], ('LDA','idxu'):[0xA6], ('LEAU','idxu'):[0x33],
 ('CMPB','idxu'):[0xE1], ('CMPA','idxu'):[0xA1], ('STA','idxu'):[0xA7],
 ('CMPA','imm'):[0x81], ('LDA','imm'):[0x86], ('LDB','imm'):[0xC6],
 ('BITA','imm'):[0x85], ('BITB','imm'):[0xC5], ('ANDA','imm'):[0x84],
 ('EORA','imm'):[0x88], ('ORA','imm'):[0x8A], ('CMPB','imm'):[0xC1], ('ADDB','imm'):[0xCB], ('ADDA','imm'):[0x8B],
 ('SUBB','imm'):[0xC0], ('SUBA','imm'):[0x80], ('ORB','imm'):[0xCA],
 ('ANDB','imm'):[0xC4], ('EORB','imm'):[0xC8],
 ('LDA','idx'):[0xA6,0x88], ('LDB','idx'):[0xE6,0x88],
 ('STA','idx'):[0xA7,0x88], ('STB','idx'):[0xE7,0x88],
 ('CMPA','idx'):[0xA1,0x88], ('BITA','idx'):[0xA5,0x88],
 ('ORA','idx'):[0xAA,0x88], ('ORB','idx'):[0xEA,0x88],
 ('ANDA','idx'):[0xA4,0x88], ('ANDB','idx'):[0xE4,0x88],
 ('EORA','idx'):[0xA8,0x88], ('EORB','idx'):[0xE8,0x88],
 ('ADDA','idx'):[0xAB,0x88], ('ADDB','idx'):[0xEB,0x88],
 ('CMPB','idx'):[0xE1,0x88], ('BITB','idx'):[0xE5,0x88],
 ('CLR','idx'):[0x6F,0x88], ('DEC','idx'):[0x6A,0x88], ('INC','idx'):[0x6C,0x88],
 ('LDB','idxu'):[0xE6], ('LDA','idxu'):[0xA6], ('LEAU','idxu'):[0x33],
 ('CMPB','idxu'):[0xE1], ('CMPA','idxu'):[0xA1],
 ('PSHS','psh'):[0x34], ('PULS','psh'):[0x35],
 ('TFR','tfr'):[0x1F], ('EXG','tfr'):[0x1E],
 ('RTS','inh'):[0x39], ('NOP','inh'):[0x12], ('CLRA','inh'):[0x4F],
 ('CLRB','inh'):[0x5F], ('INCB','inh'):[0x5C], ('INCA','inh'):[0x4C],
 ('DECB','inh'):[0x5A], ('DECA','inh'):[0x4A], ('TSTA','inh'):[0x4D],
 ('TSTB','inh'):[0x5D], ('LSRA','inh'):[0x44], ('LSRB','inh'):[0x54],
 ('JSR','ext'):[0xBD], ('JMP','ext'):[0x7E],
 ('BRA','rel'):[0x20], ('BEQ','rel'):[0x27], ('BNE','rel'):[0x26],
 ('BCC','rel'):[0x24], ('BCS','rel'):[0x25], ('BPL','rel'):[0x2A],
 ('BMI','rel'):[0x2B],
}
TFRREG = {'D':0,'X':1,'Y':2,'U':3,'S':4,'PC':5,'A':8,'B':9,'CC':10,'DP':11}
REG = {'A':0x02,'B':0x04,'X':0x10,'Y':0x20,'U':0x40,'CC':0x01,'DP':0x08}


def _num(s):
    s = s.strip()
    if s.startswith('#'): s = s[1:]
    if s.startswith('$'): return int(s[1:], 16)
    return int(s, 0)


def asm(base, src):
    lines = []
    for raw in src.strip().splitlines():
        raw = raw.split(';')[0].strip()
        if not raw: continue
        lab = None
        m = re.match(r'^([A-Za-z_]\w*):\s*(.*)$', raw)
        if m:
            lab, raw = m.group(1), m.group(2).strip()
        lines.append((lab, raw))

    # pasada 1: tamanos y etiquetas
    labels, pc, items = {}, base, []
    for lab, txt in lines:
        if lab: labels[lab] = pc
        if not txt:
            items.append((pc, None, None, None)); continue
        parts = txt.split(None, 1)
        mn = parts[0].upper()
        op = parts[1].strip() if len(parts) > 1 else ''
        if mn in ('TFR','EXG'):     mode, size = 'tfr', 2
        elif mn in ('PSHS','PULS'): mode, size = 'psh', 2
        elif not op:                mode, size = 'inh', 1
        elif op.startswith('#'):
            if (mn, 'imm16') in OPC:
                mode = 'imm16'
                size = 4 if mn in ('LDY','CMPY','LDS') else 3
            else:                    mode, size = 'imm', 2
        elif op == ',S':            mode, size = 'idxs', 2
        elif op.endswith(',U'):     mode, size = 'idxu', 2
        elif op.endswith(',X'):     mode, size = 'idx', 3
        elif (mn, 'rel') in OPC:    mode, size = 'rel', 2
        else:                       mode, size = 'ext', 3
        items.append((pc, mn, mode, op))
        pc += size

    # pasada 2: bytes
    out = bytearray()
    for pc, mn, mode, op in items:
        if mn is None: continue
        key = (mn, mode)
        if key not in OPC:
            raise ValueError('no soportado: %s %s (%s)' % (mn, op, mode))
        out += bytes(OPC[key])
        if mode == 'imm16':
            v=_num(op); out += bytes([(v>>8)&0xFF, v&0xFF])
        elif mode == 'imm':
            out.append(_num(op) & 0xFF)
        elif mode == 'idx':
            out.append(_num(op.split(',')[0]) & 0xFF)
        elif mode == 'idxs':
            pass
        elif mode == 'idxu':
            n = op.split(',')[0].strip()
            if n.upper() in ('A','B'):
                out.append(0xC6 if n.upper()=='A' else 0xC5)
                continue
            v = 0 if n == '' else _num(n)
            out.append(0xC4 if v == 0 else (0xC8 if -128 <= v <= 127 else 0xC9))
            if v != 0: out.append(v & 0xFF)
        elif mode == 'tfr':
            a,b = [x.strip().upper() for x in op.split(',')]
            out.append((TFRREG[a] << 4) | TFRREG[b])
        elif mode == 'psh':
            v = 0
            for r in op.split(','): v |= REG[r.strip().upper()]
            out.append(v)
        elif mode == 'rel':
            tgt = labels[op] if op in labels else _num(op)
            d = tgt - (pc + 2)
            if not -128 <= d <= 127:
                raise ValueError('salto fuera de rango a %s' % op)
            out.append(d & 0xFF)
        elif mode == 'ext':
            tgt = labels[op] if op in labels else _num(op)
            out += bytes([(tgt >> 8) & 0xFF, tgt & 0xFF])
    return bytes(out), labels
