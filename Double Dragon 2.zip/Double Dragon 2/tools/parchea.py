#!/usr/bin/env python3
"""parchea.py - aplica los BPS de la v52 sobre un ddragon2.zip virgen.

Por que no hay UN solo parche: el juego no es una ROM, son 18 ficheros
dentro de un zip. La v52 solo toca DOS:

    26a9-04.bin   CPU principal      233 bytes
    26ac-0e.63    banco conmutado      4 bytes

Un parche del zip entero no valdria: el MD5 del zip depende de la
compresion y del orden de los ficheros, asi que el mismo contenido da
zips distintos (norma 479). Se parchean las ROMs de dentro, que es lo
unico estable.

    python3 tools/parchea.py ddragon2.zip [salida.zip]

Sin salida, escribe `ddragon2_v52.zip` al lado del original.
"""
import hashlib
import os
import shutil
import sys
import zipfile

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(RAIZ, 'tools'))
# copia local a proposito: si esto se comparte, no puede depender de que
# exista el proyecto del Momotaro al lado.
from bps import aplicar

PARCHES = {
    '26a9-04.bin': ('26a9-04.bin.bps',
                    'b8ce1f29bb973601ff5f95b3073880a0',    # virgen
                    '3f5f52bd363519ca55b94293e7d58a47'),   # v52
    '26ac-0e.63': ('26ac-0e.63.bps',
                   'a459bd618ba87032fec636ee34e5adac',
                   'ba36cb71f1437b947bab2b50f09234f2'),
}


def md5(b):
    return hashlib.md5(b).hexdigest()


def parchea(origen, salida=None):
    salida = salida or os.path.join(os.path.dirname(origen) or '.',
                                    'ddragon2_v52.zip')
    dir_p = os.path.join(RAIZ, 'parches')
    zin = zipfile.ZipFile(origen)
    # el zip de David trae una carpeta __MACOSX con metadatos: se ignora
    reales = [n for n in zin.namelist() if not n.startswith('__MACOSX')]
    corto = {n.split('/')[-1]: n for n in reales}

    for rom in PARCHES:
        assert rom in corto, 'al zip le falta %s' % rom

    with zipfile.ZipFile(salida, 'w', zipfile.ZIP_DEFLATED) as zout:
        for n in sorted(reales):
            base = n.split('/')[-1]
            datos = zin.read(n)
            if base in PARCHES:
                bps, md5_ini, md5_fin = PARCHES[base]
                assert md5(datos) == md5_ini, \
                    '%s no es la version esperada (MD5 %s, esperaba %s)' % (
                        base, md5(datos), md5_ini)
                p = open(os.path.join(dir_p, bps), 'rb').read()
                datos = aplicar(datos, p)
                assert md5(datos) == md5_fin, \
                    '%s: el parche no da el resultado esperado' % base
                print('  %-14s parcheado  %s' % (base, md5(datos)))
            zout.writestr(base, datos)
    print('%s escrito (%d ficheros)' % (salida, len(reales)))
    return salida


if __name__ == '__main__':
    parchea(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
