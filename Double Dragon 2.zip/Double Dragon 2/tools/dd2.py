"""dd2.py - atajos para Double Dragon II.

MEDIDO:
- Los .state de David son de RetroArch: RZIP (zlib desde el offset 24) y,
  ya descomprimidos, cabecera 'RASTATE' + bloque 'MEM ' con tamaño LE32.
  Los datos que traga el core empiezan en el offset 16 y miden 18244 B,
  exactamente lo que devuelve retro_serialize.
- Botones (medidos leyendo la RAM en los offsets 997/998 del savestate):
      RetroPad B -> Fire 1 -> bit $10
      RetroPad A -> Fire 2 -> bit $20
      RetroPad Y -> Fire 3 -> bit $40
"""
import glob
import os
import sys
import zlib

sys.path.insert(0, os.path.dirname(__file__))
from fba import FBA

ROM = 'roms/ddragon2.zip'
BOTON = {0x10: 'B', 0x20: 'A', 0x40: 'Y'}


def carga(f, nombre):
    """Carga un .state de David en la instancia FBA."""
    path = nombre
    if not os.path.exists(path):
        cands = [p for p in glob.glob('states/*.state') if nombre.lower() in p.lower()]
        if not cands:
            raise FileNotFoundError(nombre)
        path = cands[0]
    d = zlib.decompress(open(path, 'rb').read()[24:])
    n = len(f.state())
    if not f.load_state(d[16:16 + n]):
        raise RuntimeError('no carga: %s' % path)
    return path


def abre():
    f = FBA(ROM)
    f.run(120)
    return f
