"""tronco3.py - MANTIENE el boton (no lo suelta) desde el state del tronco.
David: 'tengo el boton de puno pulsado... en cuanto sueltes, patea'."""
import os, sys, zlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
BASE = 0x3A2
def carga(f):
    d = zlib.decompress(open('states/tronco.state','rb').read()[24:])
    n = len(f.state()); return f.load_state(d[16:16+n])
zipp, bot, n = sys.argv[1], sys.argv[2], int(sys.argv[3])
f = FBA(zipp); f.run(120); carga(f)
out=[]
for i in range(30):
    f.hold(bot) if (bot!='-' and i<n) else f.release()
    f.run(1); s=f.state()
    out.append('%02X:%02X'%(s[BASE+0x21],s[BASE+2]))
print('  %-4s mant %-2s x%-2d | 21:spr = %s'
      % (os.path.basename(os.path.dirname(zipp)), bot, n, ' '.join(out[:16])))
