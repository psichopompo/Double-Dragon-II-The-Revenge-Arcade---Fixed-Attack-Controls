"""estres.py - SESION LARGA con entradas variadas. Verifica en CADA golpe
que la accion elegida corresponde al boton pulsado. Reporta violaciones.

Motivo: mis pruebas anteriores median UN golpe en UNA situacion. David juega
de todo. Hay que barrer muchas situaciones y buscar el contraejemplo.
"""
import os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
BASE = 0x3A2

def sesion(zipp, semilla, nframes=3000):
    rnd = random.Random(semilla)
    f = FBA(zipp); f.run(200)
    f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
    f.press('START',frames=4,after=10); f.run(600)
    viol, golpes = [], 0
    prev1E, prevbot, hist = 0, None, []
    botones, held, restantes = [], set(), 0
    for n in range(nframes):
        if restantes <= 0:
            held = set()
            r = rnd.random()
            if r < 0.30: held = {rnd.choice(['LEFT','RIGHT','UP','DOWN'])}
            elif r < 0.50: held = {rnd.choice(['B','Y'])}
            elif r < 0.60: held = {'A'}
            elif r < 0.70: held = {rnd.choice(['B','Y']), rnd.choice(['LEFT','RIGHT'])}
            elif r < 0.75: held = {'A', rnd.choice(['B','Y'])}
            restantes = rnd.randint(2, 14)
        restantes -= 1
        f.hold(*held) if held else f.release()
        f.run(1)
        s = f.state()
        a = s[BASE+0x1E]
        hist.append((set(held), a, s[BASE+5]))
        # ¿arranca un golpe? transicion a 0 o 1 desde otra cosa
        if a in (0,1) and prev1E not in (0,1):
            # ¿que boton se pulso en los ultimos 6 frames?
            bots = set()
            for h,_,_ in hist[-6:]:
                bots |= (h & {'B','Y'})
            if len(bots) == 1:
                b = bots.pop()
                # Fire1(B)=COZ(1)  Fire3(Y)=PUÑO(0)  segun decision de David
                esperado = 1 if b == 'B' else 0
                golpes += 1
                if a != esperado:
                    viol.append((n, b, a, esperado))
        prev1E = a
    return golpes, viol

if __name__ == '__main__':
    zipp, sem = sys.argv[1], int(sys.argv[2])
    g, v = sesion(zipp, sem)
    print('%-24s semilla=%d  golpes=%d  VIOLACIONES=%d'
          % (os.path.basename(os.path.dirname(zipp)), sem, g, len(v)))
    for n,b,a,e in v[:12]:
        print('    frame %4d  boton %s -> accion %02X (esperaba %02X)' % (n,b,a,e))
