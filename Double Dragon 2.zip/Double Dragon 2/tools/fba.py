"""fba.py - arnés de FB Alpha 2012 (libretro) para Double Dragon II.

Es el mismo core que usa David. Compilado aquí desde
https://github.com/libretro/fbalpha2012 (commit 0ce3153).

USO
---
    from fba import FBA
    f = FBA('roms/ddragon2.zip')
    f.run(600)
    f.png('/tmp/foto.png')
    f.press('B1'); f.run(4); f.release()

Nada de esto escribe en la ROM del disco.
"""
import ctypes
import os
from ctypes import (CDLL, CFUNCTYPE, POINTER, Structure, byref, c_bool,
                    c_char_p, c_int, c_int16, c_size_t, c_uint, c_void_p,
                    cast, create_string_buffer, string_at)
from pathlib import Path

SO = str(Path(__file__).with_name('bin') / 'fbalpha2012_libretro.so')

# libretro env
ENV_GET_SYSTEM_DIRECTORY = 9
ENV_SET_PIXEL_FORMAT = 10
ENV_GET_VARIABLE = 15
ENV_GET_SAVE_DIRECTORY = 31

# ids de RetroPad. En FBA el mapeo por defecto de un arcade de 3 botones es
#   B -> boton 1,  A -> boton 2,  Y -> boton 3
RETRO = {'B': 0, 'Y': 1, 'SELECT': 2, 'START': 3, 'UP': 4, 'DOWN': 5,
         'LEFT': 6, 'RIGHT': 7, 'A': 8, 'X': 9, 'L': 10, 'R': 11}

MEM_SAVE_RAM, MEM_SYSTEM_RAM, MEM_VIDEO_RAM = 0, 2, 3


class GameInfo(Structure):
    _fields_ = [('path', c_char_p), ('data', c_void_p),
                ('size', c_size_t), ('meta', c_char_p)]


class AVInfo(Structure):
    _fields_ = [('base_w', c_uint), ('base_h', c_uint),
                ('max_w', c_uint), ('max_h', c_uint),
                ('aspect', ctypes.c_float),
                ('fps', ctypes.c_double), ('sample_rate', ctypes.c_double)]


ENVCB = CFUNCTYPE(c_bool, c_uint, c_void_p)
VIDEOCB = CFUNCTYPE(None, c_void_p, c_uint, c_uint, c_size_t)
AUDIOCB = CFUNCTYPE(None, c_int16, c_int16)
AUDIOBCB = CFUNCTYPE(c_size_t, POINTER(c_int16), c_size_t)
POLLCB = CFUNCTYPE(None)
INPUTCB = CFUNCTYPE(c_int16, c_uint, c_uint, c_uint, c_uint)


class FBA:
    def __init__(self, zippath, sysdir=None):
        zippath = str(Path(zippath).resolve())
        self.romdir = str(Path(zippath).parent)
        sysdir = sysdir or self.romdir
        self.sysdir = create_string_buffer(sysdir.encode())
        self.core = CDLL(SO)
        self.frame = None
        self.nframe = 0
        self.buttons = set()
        self.buttons2 = set()

        self._env = ENVCB(self._on_env)
        self._video = VIDEOCB(self._on_video)
        self._audio = AUDIOCB(lambda l, r: None)
        self._audiob = AUDIOBCB(lambda d, n: n)
        self._poll = POLLCB(lambda: None)
        self._input = INPUTCB(self._on_input)

        c = self.core
        c.retro_set_environment(self._env)
        c.retro_set_video_refresh(self._video)
        c.retro_set_audio_sample(self._audio)
        c.retro_set_audio_sample_batch(self._audiob)
        c.retro_set_input_poll(self._poll)
        c.retro_set_input_state(self._input)
        c.retro_init()

        data = open(zippath, 'rb').read()
        self._rom = create_string_buffer(data, len(data))
        gi = GameInfo(path=zippath.encode(), data=cast(self._rom, c_void_p),
                      size=len(data), meta=None)
        c.retro_load_game.restype = c_bool
        if not c.retro_load_game(byref(gi)):
            raise RuntimeError('retro_load_game falló para %s' % zippath)

        c.retro_set_controller_port_device(0, 1)
        c.retro_set_controller_port_device(1, 1)
        av = AVInfo()
        c.retro_get_system_av_info(byref(av))
        self.av = av

    # ---- callbacks -----------------------------------------------------
    def _on_env(self, cmd, data):
        if cmd == ENV_SET_PIXEL_FORMAT:
            return True
        if cmd in (ENV_GET_SYSTEM_DIRECTORY, ENV_GET_SAVE_DIRECTORY):
            cast(data, POINTER(c_void_p))[0] = cast(self.sysdir, c_void_p)
            return True
        return False

    def _on_video(self, data, w, h, pitch):
        if data:
            self.frame = (string_at(data, pitch * h), w, h, pitch)

    def _on_input(self, port, device, index, ident):
        """MEDIDO: FBA2012 pide el estado como BITMASK (id 256), no boton a
        boton. Si se devuelve 1 para cualquier id pulsado, el core interpreta
        que TODOS los botones estan pulsados y el juego no responde a
        ninguno. Hay que contestar el bitmask cuando lo pide."""
        botones = self.buttons if port == 0 else self.buttons2
        if port > 1:
            return 0
        if ident == 256:                       # RETRO_DEVICE_ID_JOYPAD_MASK
            m = 0
            for b in botones:
                m |= 1 << b
            return m
        return 1 if ident in botones else 0

    # ---- control -------------------------------------------------------
    def run(self, n=1):
        for _ in range(n):
            self.core.retro_run()
            self.nframe += 1
        return self

    def hold(self, *names):
        self.buttons = {RETRO[n] for n in names}
        return self

    def hold2(self, *names):
        """Igual, para el JUGADOR 2 (puerto 1)."""
        self.buttons2 = {RETRO[n] for n in names}
        return self

    def release(self):
        self.buttons = set()
        return self

    def release2(self):
        self.buttons2 = set()
        return self

    def press(self, *names, frames=3, after=3):
        self.hold(*names)
        self.run(frames)
        self.release()
        if after:
            self.run(after)
        return self

    # ---- memoria -------------------------------------------------------
    def _mem(self, which):
        self.core.retro_get_memory_data.restype = c_void_p
        self.core.retro_get_memory_size.restype = c_size_t
        p = self.core.retro_get_memory_data(which)
        n = self.core.retro_get_memory_size(which)
        return string_at(p, n) if p and n else b''

    def ram(self):
        return self._mem(MEM_SYSTEM_RAM)

    # ---- estado --------------------------------------------------------
    def state(self):
        self.core.retro_serialize_size.restype = c_size_t
        n = self.core.retro_serialize_size()
        buf = create_string_buffer(n)
        self.core.retro_serialize(buf, n)
        return buf.raw

    def load_state(self, blob):
        buf = create_string_buffer(blob, len(blob))
        return bool(self.core.retro_unserialize(buf, len(blob)))

    # ---- imagen --------------------------------------------------------
    def rgb(self):
        if not self.frame:
            return None
        raw, w, h, pitch = self.frame
        out = []
        for y in range(h):
            row = []
            off = y * pitch
            for x in range(w):
                px = raw[off + x * 2] | raw[off + x * 2 + 1] << 8
                r = (px >> 11) & 0x1F
                g = (px >> 5) & 0x3F
                b = px & 0x1F
                row.append((r << 3 | r >> 2, g << 2 | g >> 4, b << 3 | b >> 2))
            out.append(row)
        return out

    def png(self, path):
        from PIL import Image
        rows = self.rgb()
        if not rows:
            return None
        h, w = len(rows), len(rows[0])
        im = Image.new('RGB', (w, h))
        im.putdata([p for row in rows for p in row])
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        im.save(path)
        return path

    def close(self):
        self.core.retro_unload_game()
        self.core.retro_deinit()
