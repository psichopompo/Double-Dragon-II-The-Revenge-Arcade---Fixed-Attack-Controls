"""simul.py - SALTO + ATAQUE PULSADOS A LA VEZ (lo que describe David:
codazo y patada a ras de suelo). Distinto de 'salto y luego ataque'."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
from reposo import hasta_reposo
BASE = 0x3A2
zipp, giro, bot = sys.argv[1], sys.argv[2], sys.argv[3]
f = FBA(zipp); f.run(200)
f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
f.press('START',frames=4,after=10); f.run(900)
f.hold(giro); f.run(8); f.release(); hasta_reposo(f)
spr=[]; acc=[]
for i in range(30):
    if i < 4: f.hold('A', bot)      # LOS DOS A LA VEZ
    else: f.release()
    f.run(1)
    s=f.state()
    spr.append(s[BASE+0x02]); acc.append(s[BASE+0x1E])
print('%-6s A+%-2s  spr:' % (giro,bot), ' '.join('%02X'%x for x in spr[:22]))
print('              1E :', ' '.join('%02X'%x for x in acc[:22]))
