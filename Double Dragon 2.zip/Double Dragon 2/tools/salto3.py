"""salto3.py - salta DESPUES de que la animacion del ataque haya TERMINADO
del todo (usa hasta_reposo, no una espera fija)."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
from reposo import hasta_reposo
BASE = 0x3A2
zipp, giro = sys.argv[1], sys.argv[2]
f = FBA(zipp); f.run(200)
f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
f.press('START',frames=4,after=10); f.run(900)
f.hold(giro); f.run(8); f.release(); hasta_reposo(f)
def salta(tag):
    f.hold('A'); f.run(3); f.release()
    acc=set()
    for i in range(26):
        f.run(1); acc.add(f.state()[BASE+0x1E])
    hasta_reposo(f)
    print('   %-24s 1E vistas: %s' % (tag, sorted('%02X'%a for a in acc)))
print('%s %s  (+27 tras reposo = %02X)' % (os.path.basename(os.path.dirname(zipp)),giro,
       f.state()[BASE+0x27]))
salta('salto ANTES de atacar')
f.hold('Y'); f.run(4); f.release()
hasta_reposo(f)
print('   +27 tras el puño y reposo: %02X' % f.state()[BASE+0x27])
salta('salto DESPUES del puño')
