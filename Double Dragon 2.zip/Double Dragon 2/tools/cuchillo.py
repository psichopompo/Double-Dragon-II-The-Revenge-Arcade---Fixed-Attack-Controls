"""cuchillo.py - carga el state de David con el CUCHILLO en la mano y
prueba un boton. Uso: cuchillo.py <zip> <boton|-> [salto]"""
import os, sys, zlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
BASE = 0x3A2
ST = 'states/ddragon2_cuchillo.state'

def carga(f):
    d = zlib.decompress(open(ST,'rb').read()[24:])
    n = len(f.state())
    return f.load_state(d[16:16+n])

if __name__ == '__main__':
    zipp = sys.argv[1]
    bot  = sys.argv[2]
    salto = len(sys.argv) > 3 and sys.argv[3] == 'salto'
    f = FBA(zipp); f.run(120)
    if not carga(f):
        print('NO CARGA'); sys.exit(1)
    f.run(int(os.environ.get('ESPERA','25')))
    s0 = f.state()
    print('  %-5s %s%-2s  +21=%02X flip=%02X 1E=%02X spr=%02X'
          % (os.path.basename(os.path.dirname(zipp)), 'A+' if salto else '  ',
             bot, s0[BASE+0x21], s0[BASE+3], s0[BASE+0x1E], s0[BASE+2]))
    out=[]
    for i in range(20):
        h=[]
        if salto and i<4: h.append('A')
        if bot!='-' and i<4: h.append(bot)
        f.hold(*h) if h else f.release()
        f.run(1)
        st=f.state()
        out.append('%02X/%02X:%02X' % (st[BASE+0x21], st[BASE+0x1E], st[BASE+2]))
    print('     21/1E:spr =', ' '.join(out[:12]))
