"""dis6809.py - desensamblador 6809 minimo pero suficiente para leer el
codigo de Double Dragon II. No pretende cubrir todo el juego de opcodes:
cubre lo que aparece y marca el resto como .db.
"""
import sys

# opcodes de 1 byte: (mnemo, modo)
# modos: inh, imm8, imm16, dir, ext, idx, rel8, rel16
OPS = {
0x00:('NEG','dir'),0x03:('COM','dir'),0x04:('LSR','dir'),0x06:('ROR','dir'),
0x07:('ASR','dir'),0x08:('ASL','dir'),0x09:('ROL','dir'),0x0A:('DEC','dir'),
0x0C:('INC','dir'),0x0D:('TST','dir'),0x0E:('JMP','dir'),0x0F:('CLR','dir'),
0x12:('NOP','inh'),0x13:('SYNC','inh'),0x16:('LBRA','rel16'),0x17:('LBSR','rel16'),
0x19:('DAA','inh'),0x1A:('ORCC','imm8'),0x1C:('ANDCC','imm8'),0x1D:('SEX','inh'),
0x1E:('EXG','imm8'),0x1F:('TFR','imm8'),
0x20:('BRA','rel8'),0x21:('BRN','rel8'),0x22:('BHI','rel8'),0x23:('BLS','rel8'),
0x24:('BCC','rel8'),0x25:('BCS','rel8'),0x26:('BNE','rel8'),0x27:('BEQ','rel8'),
0x28:('BVC','rel8'),0x29:('BVS','rel8'),0x2A:('BPL','rel8'),0x2B:('BMI','rel8'),
0x2C:('BGE','rel8'),0x2D:('BLT','rel8'),0x2E:('BGT','rel8'),0x2F:('BLE','rel8'),
0x30:('LEAX','idx'),0x31:('LEAY','idx'),0x32:('LEAS','idx'),0x33:('LEAU','idx'),
0x34:('PSHS','imm8'),0x35:('PULS','imm8'),0x36:('PSHU','imm8'),0x37:('PULU','imm8'),
0x39:('RTS','inh'),0x3A:('ABX','inh'),0x3B:('RTI','inh'),0x3D:('MUL','inh'),
0x3F:('SWI','inh'),
0x40:('NEGA','inh'),0x43:('COMA','inh'),0x44:('LSRA','inh'),0x46:('RORA','inh'),
0x47:('ASRA','inh'),0x48:('ASLA','inh'),0x49:('ROLA','inh'),0x4A:('DECA','inh'),
0x4C:('INCA','inh'),0x4D:('TSTA','inh'),0x4F:('CLRA','inh'),
0x50:('NEGB','inh'),0x53:('COMB','inh'),0x54:('LSRB','inh'),0x56:('RORB','inh'),
0x57:('ASRB','inh'),0x58:('ASLB','inh'),0x59:('ROLB','inh'),0x5A:('DECB','inh'),
0x5C:('INCB','inh'),0x5D:('TSTB','inh'),0x5F:('CLRB','inh'),
0x60:('NEG','idx'),0x63:('COM','idx'),0x64:('LSR','idx'),0x66:('ROR','idx'),
0x67:('ASR','idx'),0x68:('ASL','idx'),0x69:('ROL','idx'),0x6A:('DEC','idx'),
0x6C:('INC','idx'),0x6D:('TST','idx'),0x6E:('JMP','idx'),0x6F:('CLR','idx'),
0x70:('NEG','ext'),0x73:('COM','ext'),0x74:('LSR','ext'),0x76:('ROR','ext'),
0x77:('ASR','ext'),0x78:('ASL','ext'),0x79:('ROL','ext'),0x7A:('DEC','ext'),
0x7C:('INC','ext'),0x7D:('TST','ext'),0x7E:('JMP','ext'),0x7F:('CLR','ext'),
0x80:('SUBA','imm8'),0x81:('CMPA','imm8'),0x82:('SBCA','imm8'),0x83:('SUBD','imm16'),
0x84:('ANDA','imm8'),0x85:('BITA','imm8'),0x86:('LDA','imm8'),0x88:('EORA','imm8'),
0x89:('ADCA','imm8'),0x8A:('ORA','imm8'),0x8B:('ADDA','imm8'),0x8C:('CMPX','imm16'),
0x8D:('BSR','rel8'),0x8E:('LDX','imm16'),
0x90:('SUBA','dir'),0x91:('CMPA','dir'),0x92:('SBCA','dir'),0x93:('SUBD','dir'),
0x94:('ANDA','dir'),0x95:('BITA','dir'),0x96:('LDA','dir'),0x97:('STA','dir'),
0x98:('EORA','dir'),0x99:('ADCA','dir'),0x9A:('ORA','dir'),0x9B:('ADDA','dir'),
0x9C:('CMPX','dir'),0x9D:('JSR','dir'),0x9E:('LDX','dir'),0x9F:('STX','dir'),
0xA0:('SUBA','idx'),0xA1:('CMPA','idx'),0xA2:('SBCA','idx'),0xA3:('SUBD','idx'),
0xA4:('ANDA','idx'),0xA5:('BITA','idx'),0xA6:('LDA','idx'),0xA7:('STA','idx'),
0xA8:('EORA','idx'),0xA9:('ADCA','idx'),0xAA:('ORA','idx'),0xAB:('ADDA','idx'),
0xAC:('CMPX','idx'),0xAD:('JSR','idx'),0xAE:('LDX','idx'),0xAF:('STX','idx'),
0xB0:('SUBA','ext'),0xB1:('CMPA','ext'),0xB2:('SBCA','ext'),0xB3:('SUBD','ext'),
0xB4:('ANDA','ext'),0xB5:('BITA','ext'),0xB6:('LDA','ext'),0xB7:('STA','ext'),
0xB8:('EORA','ext'),0xB9:('ADCA','ext'),0xBA:('ORA','ext'),0xBB:('ADDA','ext'),
0xBC:('CMPX','ext'),0xBD:('JSR','ext'),0xBE:('LDX','ext'),0xBF:('STX','ext'),
0xC0:('SUBB','imm8'),0xC1:('CMPB','imm8'),0xC2:('SBCB','imm8'),0xC3:('ADDD','imm16'),
0xC4:('ANDB','imm8'),0xC5:('BITB','imm8'),0xC6:('LDB','imm8'),0xC8:('EORB','imm8'),
0xC9:('ADCB','imm8'),0xCA:('ORB','imm8'),0xCB:('ADDB','imm8'),0xCC:('LDD','imm16'),
0xCE:('LDU','imm16'),
0xD0:('SUBB','dir'),0xD1:('CMPB','dir'),0xD2:('SBCB','dir'),0xD3:('ADDD','dir'),
0xD4:('ANDB','dir'),0xD5:('BITB','dir'),0xD6:('LDB','dir'),0xD7:('STB','dir'),
0xD8:('EORB','dir'),0xD9:('ADCB','dir'),0xDA:('ORB','dir'),0xDB:('ADDB','dir'),
0xDC:('LDD','dir'),0xDD:('STD','dir'),0xDE:('LDU','dir'),0xDF:('STU','dir'),
0xE0:('SUBB','idx'),0xE1:('CMPB','idx'),0xE2:('SBCB','idx'),0xE3:('ADDD','idx'),
0xE4:('ANDB','idx'),0xE5:('BITB','idx'),0xE6:('LDB','idx'),0xE7:('STB','idx'),
0xE8:('EORB','idx'),0xE9:('ADCB','idx'),0xEA:('ORB','idx'),0xEB:('ADDB','idx'),
0xEC:('LDD','idx'),0xED:('STD','idx'),0xEE:('LDU','idx'),0xEF:('STU','idx'),
0xF0:('SUBB','ext'),0xF1:('CMPB','ext'),0xF2:('SBCB','ext'),0xF3:('ADDD','ext'),
0xF4:('ANDB','ext'),0xF5:('BITB','ext'),0xF6:('LDB','ext'),0xF7:('STB','ext'),
0xF8:('EORB','ext'),0xF9:('ADCB','ext'),0xFA:('ORB','ext'),0xFB:('ADDB','ext'),
0xFC:('LDD','ext'),0xFD:('STD','ext'),0xFE:('LDU','ext'),0xFF:('STU','ext'),
}
# page 2 (0x10 xx)
OPS10 = {
0x21:('LBRN','rel16'),0x22:('LBHI','rel16'),0x23:('LBLS','rel16'),
0x24:('LBCC','rel16'),0x25:('LBCS','rel16'),0x26:('LBNE','rel16'),
0x27:('LBEQ','rel16'),0x28:('LBVC','rel16'),0x29:('LBVS','rel16'),
0x2A:('LBPL','rel16'),0x2B:('LBMI','rel16'),0x2C:('LBGE','rel16'),
0x2D:('LBLT','rel16'),0x2E:('LBGT','rel16'),0x2F:('LBLE','rel16'),
0x83:('CMPD','imm16'),0x8C:('CMPY','imm16'),0x8E:('LDY','imm16'),
0x93:('CMPD','dir'),0x9C:('CMPY','dir'),0x9E:('LDY','dir'),0x9F:('STY','dir'),
0xA3:('CMPD','idx'),0xAC:('CMPY','idx'),0xAE:('LDY','idx'),0xAF:('STY','idx'),
0xB3:('CMPD','ext'),0xBC:('CMPY','ext'),0xBE:('LDY','ext'),0xBF:('STY','ext'),
0xCE:('LDS','imm16'),0xDE:('LDS','dir'),0xDF:('STS','dir'),
0xEE:('LDS','idx'),0xEF:('STS','idx'),0xFE:('LDS','ext'),0xFF:('STS','ext'),
}
OPS11 = {0x83:('CMPU','imm16'),0x8C:('CMPS','imm16'),0x93:('CMPU','dir'),
         0x9C:('CMPS','dir'),0xA3:('CMPU','idx'),0xAC:('CMPS','idx'),
         0xB3:('CMPU','ext'),0xBC:('CMPS','ext')}

REG = ['X','Y','U','S']


def idx_operand(d, i):
    """devuelve (texto, bytes_consumidos) del postbyte indexado"""
    pb = d[i]
    r = REG[(pb >> 5) & 3]
    if not (pb & 0x80):
        off = pb & 0x1F
        if off & 0x10:
            off -= 0x20
        return ('%d,%s' % (off, r), 1)
    m = pb & 0x0F
    ind = bool(pb & 0x10)
    def wrap(s):
        return '[%s]' % s if ind else s
    if m == 0x00: return (wrap(',%s+' % r), 1)
    if m == 0x01: return (wrap(',%s++' % r), 1)
    if m == 0x02: return (wrap(',-%s' % r), 1)
    if m == 0x03: return (wrap(',--%s' % r), 1)
    if m == 0x04: return (wrap(',%s' % r), 1)
    if m == 0x05: return (wrap('B,%s' % r), 1)
    if m == 0x06: return (wrap('A,%s' % r), 1)
    if m == 0x08:
        o = d[i+1]; o = o-256 if o > 127 else o
        return (wrap('$%02X,%s' % (o & 0xFF, r)), 2)
    if m == 0x09:
        o = (d[i+1] << 8) | d[i+2]
        return (wrap('$%04X,%s' % (o, r)), 3)
    if m == 0x0B: return (wrap('D,%s' % r), 1)
    if m == 0x0C:
        o = d[i+1]; o = o-256 if o > 127 else o
        return (wrap('$%02X,PCR' % (o & 0xFF)), 2)
    if m == 0x0D:
        o = (d[i+1] << 8) | d[i+2]
        return (wrap('$%04X,PCR' % o), 3)
    if m == 0x0F:
        o = (d[i+1] << 8) | d[i+2]
        return (wrap('$%04X' % o), 3)
    return ('?pb%02X' % pb, 1)


def dis(d, off, n, base):
    """desensambla n instrucciones desde off; base = direccion CPU de d[0]"""
    out = []
    i = off
    for _ in range(n):
        if i >= len(d):
            break
        pc = base + i
        b = d[i]
        tbl, ln = OPS, 1
        if b == 0x10:
            tbl, ln, b = OPS10, 2, d[i+1]
        elif b == 0x11:
            tbl, ln, b = OPS11, 2, d[i+1]
        if b not in tbl:
            out.append((pc, '.db $%02X' % d[i], d[i:i+1]))
            i += 1
            continue
        mn, mo = tbl[b]
        j = i + ln
        if mo == 'inh':
            txt, sz = mn, 0
        elif mo == 'imm8':
            txt, sz = '%s #$%02X' % (mn, d[j]), 1
        elif mo == 'imm16':
            txt, sz = '%s #$%04X' % (mn, (d[j] << 8) | d[j+1]), 2
        elif mo == 'dir':
            txt, sz = '%s <$%02X' % (mn, d[j]), 1
        elif mo == 'ext':
            txt, sz = '%s $%04X' % (mn, (d[j] << 8) | d[j+1]), 2
        elif mo == 'rel8':
            o = d[j]; o = o-256 if o > 127 else o
            txt, sz = '%s $%04X' % (mn, (pc + ln + 1 + o) & 0xFFFF), 1
        elif mo == 'rel16':
            o = (d[j] << 8) | d[j+1]
            o = o-65536 if o > 32767 else o
            txt, sz = '%s $%04X' % (mn, (pc + ln + 2 + o) & 0xFFFF), 2
        elif mo == 'idx':
            s, sz = idx_operand(d, j)
            txt = '%s %s' % (mn, s)
        else:
            txt, sz = mn, 0
        end = j + sz
        out.append((pc, txt, d[i:end]))
        i = end
    return out


if __name__ == '__main__':
    f, off, n, base = sys.argv[1], int(sys.argv[2], 0), int(sys.argv[3]), int(sys.argv[4], 0)
    d = open(f, 'rb').read()
    for pc, txt, raw in dis(d, off, n, base):
        print('%04X  %-14s %s' % (pc, ' '.join('%02X' % x for x in raw), txt))
