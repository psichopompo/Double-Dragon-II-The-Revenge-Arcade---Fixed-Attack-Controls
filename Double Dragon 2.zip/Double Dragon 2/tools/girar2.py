"""girar2.py - el caso que rompia todo: MANTENER el ataque mientras se gira."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
from reposo import hasta_reposo
BASE = 0x3A2
zipp, g1, g2, bot = sys.argv[1:5]
f = FBA(zipp); f.run(200)
f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
f.press('START',frames=4,after=10); f.run(900)
f.hold(g1); f.run(8); f.release(); hasta_reposo(f)
out=[]
for i in range(34):
    if   i < 12: f.hold(bot)
    elif i < 24: f.hold(bot, g2)
    else:        f.hold(bot)
    f.run(1)
    s=f.state()
    out.append('%02X' % s[BASE+0x1E])
f.release()
print('%-5s->%-5s %-2s  1E:' % (g1,g2,bot), ''.join(out))
