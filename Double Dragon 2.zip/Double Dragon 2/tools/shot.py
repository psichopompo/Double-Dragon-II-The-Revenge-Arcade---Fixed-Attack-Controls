import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
import dd2
zipp, st, out = sys.argv[1:4]
f = FBA(zipp); f.run(120); dd2.carga(f, st); f.run(int(sys.argv[4]) if len(sys.argv)>4 else 0)
f.png(out)
