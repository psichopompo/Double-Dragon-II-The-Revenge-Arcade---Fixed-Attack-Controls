"""build.py - genera un .zip nuevo con 26a9-04.bin parcheado.

FBA carga la ROM desde el zip, asi que para probar un parche hay que
reempaquetar. El zip original NO se toca.
"""
import os
import shutil
import sys
import zipfile

ORIG = 'roms/ddragon2.zip'
CPU = '26a9-04.bin'


def construye(parches, dst, verbose=True):
    """parches: dict {offset_rom: bytes}. Offsets de 26a9-04.bin (CPU-$8000).

    OJO (medido): FBA identifica el juego por el NOMBRE del fichero, asi que
    el zip destino TIENE que llamarse ddragon2.zip. Con cualquier otro
    nombre, retro_load_game falla aunque el contenido sea identico.
    """
    if os.path.basename(dst) != 'ddragon2.zip':
        raise ValueError('el zip debe llamarse ddragon2.zip (FBA usa el nombre '
                         'para identificar el juego): %s' % dst)
    src = zipfile.ZipFile(ORIG)
    nombres = [i.filename for i in src.infolist()
               if not i.filename.startswith('__MACOSX')]
    datos = {n: src.read(n) for n in nombres}
    src.close()

    d = bytearray(datos[CPU])
    for off, b in sorted(parches.items()):
        antes = bytes(d[off:off + len(b)])
        d[off:off + len(b)] = b
        if verbose:
            print('  0x%05X  $%04X  %s -> %s'
                  % (off, 0x8000 + off,
                     ' '.join('%02X' % x for x in antes),
                     ' '.join('%02X' % x for x in b)))
    datos[CPU] = bytes(d)

    os.makedirs(os.path.dirname(dst) or '.', exist_ok=True)
    z = zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED)
    for n in nombres:
        z.writestr(n, datos[n])
    z.close()
    return dst


if __name__ == '__main__':
    construye({}, sys.argv[1] if len(sys.argv) > 1 else '/tmp/test.zip')
