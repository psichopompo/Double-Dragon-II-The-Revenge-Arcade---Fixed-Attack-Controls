#!/usr/bin/env python3
"""estres2p.py - el estres de estres.py, pero para el JUGADOR 2.

David da el P2 por bueno sin haberlo probado. Es razonable -el codigo es
el mismo y todos los ganchos van indexados por X, no a direccion fija-
pero eso es un argumento, no una medicion. Esto lo mide.

Diferencias con estres.py:

  - mete moneda y pulsa el START del PUERTO 1 para que entre el segundo
    jugador. Con solo monedas no entra: hay que darle a su START.
  - lee su bloque de estado en $0401 en vez de $03A2.
  - mueve al P2 con hold2()/release2().

    python3 tools/estres2p.py roms/v52/ddragon2.zip 1
"""
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA

P1 = 0x3A2
P2 = 0x401


def entra_p2(f):
    """Deja a los DOS jugadores en partida. Devuelve True si lo consigue."""
    f.run(200)
    for _ in range(4):
        f.press('SELECT', frames=4, after=12)
    f.run(60)
    f.hold2('START')
    f.run(8)
    f.release2()
    f.run(300)
    s = f.state()
    return s[P2] != 0 and s[P1] != 0


def sesion(zipp, semilla, nframes=3000):
    rnd = random.Random(semilla)
    f = FBA(zipp)
    assert entra_p2(f), 'el jugador 2 no ha entrado en partida'

    viol, golpes = [], 0
    prev1E, hist = 0, []
    held, restantes = set(), 0
    for n in range(nframes):
        if restantes <= 0:
            held = set()
            r = rnd.random()
            if r < 0.30:
                held = {rnd.choice(['LEFT', 'RIGHT', 'UP', 'DOWN'])}
            elif r < 0.50:
                held = {rnd.choice(['B', 'Y'])}
            elif r < 0.60:
                held = {'A'}
            elif r < 0.70:
                held = {rnd.choice(['B', 'Y']), rnd.choice(['LEFT', 'RIGHT'])}
            elif r < 0.75:
                held = {'A', rnd.choice(['B', 'Y'])}
            restantes = rnd.randint(2, 14)
        restantes -= 1
        f.hold2(*held) if held else f.release2()
        f.run(1)
        s = f.state()
        a = s[P2 + 0x1E]
        hist.append((set(held), a))
        if a in (0, 1) and prev1E not in (0, 1):
            bots = set()
            for h, _ in hist[-6:]:
                bots |= (h & {'B', 'Y'})
            if len(bots) == 1:
                b = bots.pop()
                esperado = 1 if b == 'B' else 0   # B=Fire1 coz, Y=Fire3 puño
                golpes += 1
                if a != esperado:
                    viol.append((n, b, a, esperado))
        prev1E = a
    return golpes, viol


if __name__ == '__main__':
    zipp, sem = sys.argv[1], int(sys.argv[2])
    g, v = sesion(zipp, sem)
    print('JUGADOR 2  semilla=%d  golpes=%d  VIOLACIONES=%d' % (sem, g, len(v)))
    for n, b, a, e in v[:12]:
        print('    frame %4d  boton %s -> accion %02X (esperaba %02X)'
              % (n, b, a, e))
    sys.exit(1 if v else 0)
