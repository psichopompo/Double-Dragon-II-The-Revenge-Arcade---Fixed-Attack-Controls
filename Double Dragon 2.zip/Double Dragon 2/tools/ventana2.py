"""ventana2.py - como ventana.py pero barriendo TAMBIEN la FASE de inicio.

Motivo: el buffer de $8E89 evalua cada N frames. Si empiezo a pulsar siempre
en el mismo frame absoluto, la fase del contador +$53 queda fija y el
resultado depende de ella. Con N=3 y N=5 la fase cae distinta -> mi medida
anterior de "5 se rompe" puede ser un ARTEFACTO del banco de pruebas.
"""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
from reposo import hasta_reposo
BASE = 0x3A2

def prueba(zipp, giro, bot, desfase, fase):
    f = FBA(zipp); f.run(200)
    f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
    f.press('START',frames=4,after=10); f.run(900)
    f.hold(giro); f.run(8); f.release(); hasta_reposo(f)
    f.run(fase)
    ini_s, ini_a = 5, 5 + desfase
    acc = set()
    for i in range(40):
        h = []
        if ini_s <= i < ini_s + 4: h.append('A')
        if ini_a <= i < ini_a + 4: h.append(bot)
        f.hold(*h) if h else f.release()
        f.run(1)
        acc.add(f.state()[BASE+0x1E])
    f.close()
    return 5 in acc or 6 in acc

if __name__ == '__main__':
    zipp, giro, bot = sys.argv[1], sys.argv[2], sys.argv[3]
    print('%-22s %s %s' % (os.path.basename(os.path.dirname(zipp)), giro, bot))
    print('   desfase:  ' + ' '.join('%+2d' % d for d in range(-5, 6)))
    total = {}
    for fase in range(5):
        fila = []
        for d in range(-5, 6):
            ok = prueba(zipp, giro, bot, d, fase)
            fila.append(' X' if ok else ' .')
            total[d] = total.get(d, 0) + (1 if ok else 0)
        print('   fase %d :  %s' % (fase, ' '.join(fila)))
    print('   aciertos: ' + ' '.join('%2d' % total[d] for d in range(-5, 6)))
    print('   TOTAL: %d de %d' % (sum(total.values()), 5*11))
