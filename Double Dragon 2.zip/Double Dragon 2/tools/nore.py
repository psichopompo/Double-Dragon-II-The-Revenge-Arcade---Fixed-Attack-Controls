import os, sys, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
zipp = sys.argv[1]
f = FBA(zipp)
sig = []
for lim in (200, 400, 700, 1000, 1300, 1600):
    while f.nframe < lim:
        f.run(1)
    f.png('/tmp/dd2/nr.png')
    sig.append(hashlib.md5(open('/tmp/dd2/nr.png','rb').read()).hexdigest()[:8])
print(os.path.basename(os.path.dirname(zipp)), ' '.join(sig))
