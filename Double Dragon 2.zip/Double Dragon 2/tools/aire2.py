"""aire2.py - salto + ataque, midiendo si el personaje SE DA LA VUELTA.
Compara ORIGINAL contra parche: solo es regresion si el parche voltea y el
original no."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
from reposo import hasta_reposo
BASE = 0x3A2
zipp, giro, bot, ret = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
f = FBA(zipp); f.run(200)
f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
f.press('START',frames=4,after=10); f.run(900)
f.hold(giro); f.run(8); f.release(); hasta_reposo(f)
ini = f.state()[BASE+3]
f.hold('A'); f.run(3); f.release()
fl=[]
for i in range(40):
    if ret <= i < ret+6: f.hold(bot)
    else: f.release()
    f.run(1)
    fl.append(f.state()[BASE+3])
volteos = sum(1 for a,b in zip(fl,fl[1:]) if a!=b)
print('%-6s %-2s ret=%-2d  inicial=%02X  volteos=%d  %s'
      % (giro,bot,ret,ini,volteos, ''.join('1' if x else '0' for x in fl)))
