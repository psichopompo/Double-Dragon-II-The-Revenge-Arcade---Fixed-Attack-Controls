"""aire3.py - barre el RETARDO del boton dentro del salto y registra
altura (+$09), accion (+$1E), sprite (+$02) y flip (+$03).
Objetivo: ver que ataque aereo sale segun el instante y el boton."""
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
from reposo import hasta_reposo
BASE = 0x3A2
zipp, giro, bot, ret = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
extra = sys.argv[5] if len(sys.argv) > 5 else None   # direccion mantenida en el aire
f = FBA(zipp); f.run(200)
f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
f.press('START',frames=4,after=10); f.run(900)
f.hold(giro); f.run(8); f.release(); hasta_reposo(f)
f.hold('A'); f.run(3); f.release()
alt=[]; acc=[]; spr=[]; flip=[]
for i in range(42):
    h=[]
    if ret <= i < ret+5: h.append(bot)
    if extra: h.append(extra)
    f.hold(*h) if h else f.release()
    f.run(1)
    s=f.state()
    alt.append(s[BASE+0x09]); acc.append(s[BASE+0x1E])
    spr.append(s[BASE+0x02]); flip.append(s[BASE+0x03])
print('%-5s %-2s ret=%-2d dir=%-5s' % (giro,bot,ret,extra or '-'))
print('   alt :', ' '.join('%02X'%x for x in alt[:30]))
print('   1E  :', ' '.join('%02X'%x for x in acc[:30]))
print('   spr :', ' '.join('%02X'%x for x in spr[:30]))
