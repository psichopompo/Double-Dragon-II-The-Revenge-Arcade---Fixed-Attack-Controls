"""build3.py - construye el zip parcheando VARIOS ficheros de la ROM.
Necesario desde que se localizo la 5a pasada direccional en el banco
conmutado 26ac-0e.63 (la recogida de objetos)."""
import os, zipfile
ORIG = 'roms/ddragon2.zip'

def construye3(parches, dst, verbose=False):
    """parches: {nombre_fichero: {offset: bytes}}"""
    if os.path.basename(dst) != 'ddragon2.zip':
        raise ValueError('el zip debe llamarse ddragon2.zip')
    src = zipfile.ZipFile(ORIG)
    nombres = [i.filename for i in src.infolist()
               if not i.filename.startswith('__MACOSX')]
    datos = {n: src.read(n) for n in nombres}
    src.close()
    for fich, ps in parches.items():
        d = bytearray(datos[fich])
        for off, b in sorted(ps.items()):
            if verbose:
                print('  %-12s 0x%05X  %s -> %s'
                      % (fich, off, bytes(d[off:off+len(b)]).hex(), b.hex()))
            d[off:off+len(b)] = b
        datos[fich] = bytes(d)
    os.makedirs(os.path.dirname(dst) or '.', exist_ok=True)
    z = zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED)
    for n in nombres:
        z.writestr(n, datos[n])
    z.close()
    return dst
