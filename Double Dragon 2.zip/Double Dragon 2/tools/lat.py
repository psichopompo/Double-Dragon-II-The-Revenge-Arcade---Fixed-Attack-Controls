"""lat.py - LATIGO REAL (+$21=07) conseguido por el flujo del juego.
Semilla 3: verificada valida en la ROM original y en las parcheadas.
Solo se fuerza el TIPO de arma al coger un objeto real ($A18A)."""
import os, random, sys, zipfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
BASE=0x3A2
def prep(zipp, tipo=0x07):
    d='/tmp/dd2/L_%s' % os.path.basename(os.path.dirname(zipp))
    os.makedirs(d, exist_ok=True)
    src=zipfile.ZipFile(zipp); datos={n:src.read(n) for n in src.namelist()}; src.close()
    b=bytearray(datos['26a9-04.bin']); b[0x218A:0x218C]=bytes([0x86,tipo])
    datos['26a9-04.bin']=bytes(b)
    z=zipfile.ZipFile(d+'/ddragon2.zip','w',zipfile.ZIP_DEFLATED)
    for n,v in datos.items(): z.writestr(n,v)
    z.close(); return d+'/ddragon2.zip'
def corre(zipp, modo='tierra'):
    f=FBA(prep(zipp)); f.run(200)
    f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
    f.press('START',frames=4,after=10); f.run(900)
    rnd=random.Random(3)
    for n in range(6000):
        q=rnd.random(); h=[]
        if q<0.50: h.append('RIGHT')
        elif q<0.58: h.append('LEFT')
        if q>0.78: h.append(rnd.choice(['B','Y']))
        f.hold(*h) if h else f.release()
        f.run(1)
        if f.state()[BASE+0x21]==0x07: break
    f.release(); f.run(4)
    print('%-9s latigo +21=%02X  modo=%s' %
          (os.path.basename(os.path.dirname(zipp)), f.state()[BASE+0x21], modo))
    for giro,bot in (('RIGHT','B'),('RIGHT','Y'),('LEFT','B'),('LEFT','Y')):
        if f.state()[BASE+0x21]!=0x07:
            print('   [latigo perdido]'); return
        f.hold(giro); f.run(5); f.release(); f.run(8)
        s0=f.state(); out=[]
        for i in range(14):
            h=[]
            if modo=='salto' and i<4: h.append('A')
            if i<4: h.append(bot)
            f.hold(*h) if h else f.release()
            f.run(1); st=f.state()
            out.append('%02X:%02X'%(st[BASE+0x1E],st[BASE+2]))
        print('   flip=%02X %-5s %s%-2s  1E:spr = %s'
              % (s0[BASE+3],giro,'A+' if modo=='salto' else '  ',bot,' '.join(out[:8])))
        f.run(12)
if __name__=='__main__':
    corre(sys.argv[1], sys.argv[2] if len(sys.argv)>2 else 'tierra')
