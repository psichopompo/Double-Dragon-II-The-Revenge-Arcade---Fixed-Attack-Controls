"""buscaorient.py - barre TODOS los bytes y bits del bloque de jugador y
busca cual predice la orientacion REAL en juego variado.

Verdad de referencia: el bit $80 de +$02 (codigo de sprite) es el volteo
que se ve en pantalla. Medido: 05/12/73 mirando derecha, 85/92/F3 izquierda.
"""
import os, random, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from fba import FBA
BASE = 0x3A2; N = 0x5F

zipp, sem = sys.argv[1], int(sys.argv[2])
rnd = random.Random(sem)
f = FBA(zipp); f.run(200)
f.press('SELECT',frames=4,after=10); f.press('SELECT',frames=4,after=10)
f.press('START',frames=4,after=10); f.run(600)
muestras=[]
held=set(); rest=0
for n in range(2500):
    if rest<=0:
        held=set(); r=rnd.random()
        if r<0.35: held={rnd.choice(['LEFT','RIGHT'])}
        elif r<0.55: held={rnd.choice(['B','Y'])}
        elif r<0.65: held={'A'}
        elif r<0.80: held={rnd.choice(['B','Y']), rnd.choice(['LEFT','RIGHT'])}
        rest=rnd.randint(2,12)
    rest-=1
    f.hold(*held) if held else f.release()
    f.run(1)
    s=f.state()[BASE:BASE+N]
    muestras.append(bytes(s))

# verdad: bit $80 de +$02  (1 = mira izquierda)
verdad=[(m[2]>>7)&1 for m in muestras]
n1=sum(verdad); n0=len(verdad)-n1
print('muestras=%d  derecha=%d  izquierda=%d' % (len(muestras), n0, n1))
print()
print('candidatos que predicen la orientacion (>=99%% de aciertos):')
mejores=[]
for off in range(N):
    for bit in range(8):
        pred=[(m[off]>>bit)&1 for m in muestras]
        ac=sum(1 for p,v in zip(pred,verdad) if p==v)
        inv=sum(1 for p,v in zip(pred,verdad) if p!=v)
        best=max(ac,inv); pct=100.0*best/len(verdad)
        if pct>=99.0:
            mejores.append((pct,off,bit,'directo' if ac>=inv else 'invertido'))
for pct,off,bit,s in sorted(mejores, reverse=True)[:15]:
    print('   +$%02X bit%d ($%02X)  %.1f%%  %s' % (off,bit,1<<bit,pct,s))
if not mejores:
    print('   NINGUNO llega al 99%')
    todo=[]
    for off in range(N):
        for bit in range(8):
            pred=[(m[off]>>bit)&1 for m in muestras]
            ac=sum(1 for p,v in zip(pred,verdad) if p==v)
            best=max(ac,len(verdad)-ac)
            todo.append((100.0*best/len(verdad),off,bit))
    for pct,off,bit in sorted(todo,reverse=True)[:10]:
        print('   +$%02X bit%d  %.1f%%' % (off,bit,pct))
