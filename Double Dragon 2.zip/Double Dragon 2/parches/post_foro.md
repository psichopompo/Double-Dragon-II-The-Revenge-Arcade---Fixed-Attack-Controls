# Double Dragon II (arcade) — puño y patada en el mismo botón, siempre

Llevaba tiempo con una espina clavada con el Double Dragon II de recreativa,
y por fin está resuelta. Dejo aquí el parche y la explicación.

## El problema

En la placa original de Technōs los dos botones de ataque **no son «puño» y
«patada»**. Son direccionales: uno golpea siempre hacia la izquierda de la
pantalla y el otro siempre hacia la derecha.

Como Billy se gira, eso significa que el botón que era el puño pasa a ser la
coz en cuanto cambias de lado. Y al revés. Medido en la ROM original:

```
                 ORIGINAL
mirando DERECHA    Fire1 = coz      Fire3 = puño
mirando IZQUIERDA  Fire1 = puño     Fire3 = coz
```

En 1988 era una decisión de diseño perfectamente defendible, y hay a quien le
parece parte del encanto del juego. Pero si vienes de cualquier yo-contra-el-
barrio posterior, tu cabeza espera que un botón sea siempre el mismo golpe, y
en la práctica acabas dando patadas cuando querías dar puñetazos.

## Lo que hace el parche

Rehace la gestión de la entrada para que **cada botón sea siempre el mismo
movimiento, mires hacia donde mires**:

```
Botón 1  =  patada
Botón 2  =  salto  (sin tocar)
Botón 3  =  puño
```

Y no sólo en el golpe básico. Está aplicado a todos los ataques del juego:

| Situación | Botón 1 | Botón 3 |
| --- | --- | --- |
| En el suelo | Coz | Puño |
| Salto + ataque (a la vez) | Patada al ras | Codazo |
| En el aire (tras saltar) | Patada voladora | Huracán, sólo en la cúspide |
| Con el cuchillo | Coz | Lanzarlo |
| Con el látigo | Giro | Golpe normal |
| Con pala, bate, bidón… | Coz | Golpe |
| Recoger un arma | — | Sólo con el puño |

Todo eso está probado en partida, salvo lo que aviso al final.

## La prueba

Esto es lo que sale al pulsar cada botón desde reposo, en los dos lados. La
primera pareja de números es la acción interna y el sprite que se dibuja:

```
                        ORIGINAL              CON EL PARCHE
DERECHA    Fire1        coz    spr 73/74      coz    spr 73/74
DERECHA    Fire3        puño   spr 12/13      puño   spr 12/13
IZQUIERDA  Fire1        puño   spr 92/93      coz    spr F3/F4   <-- cambia
IZQUIERDA  Fire3        coz    spr F3/F4      puño   spr 92/93   <-- cambia
```

Los sprites `92/93` y `F3/F4` son los mismos `12/13` y `73/74` con el bit de
volteo puesto (`$12|$80 = $92`): es el mismo movimiento mirando al otro lado,
no otro distinto. O sea que mirando a la derecha ya estaba bien y lo que
había que arreglar era el lado izquierdo.

## Dos cambios de apoyo

Hicieron falta para que lo anterior se comporte de forma sensata:

- **La ventana del buffer de combinaciones pasa de 3 a 4 frames.** Con 3 era
  muy fácil perder el «salto + ataque» una vez que los dos ataques dejan de
  ser intercambiables.
- **Ya no se fuerza el volteo en el aire.** En el original, el ataque aéreo
  obliga al sprite a mirar hacia donde golpea el botón. Como los botones ya
  no son direccionales, ese volteo forzado no tenía sentido.

## Un detalle que conviene saber

**El huracán sigue sin poder hacerse llevando un arma.** Eso es de fábrica,
no lo introduce el parche: la ROM original lo descarta igual. Lo aviso para
que nadie lo reporte como fallo.

## Cómo se aplica

El juego de recreativa no es una ROM suelta: son 18 ficheros dentro de
`ddragon2.zip`. El parche toca **dos**, así que hay dos `.bps`:

```
26a9-04.bin.bps   ->  26a9-04.bin   (CPU principal, 233 bytes)
26ac-0e.63.bps    ->  26ac-0e.63    (banco conmutado, 4 bytes)
```

1. Abre `ddragon2.zip` y saca `26a9-04.bin` y `26ac-0e.63`.
2. Aplica cada parche a su fichero con Flips, beat o cualquier herramienta BPS.
3. Vuelve a meter los dos ficheros en el zip, sustituyendo los originales.
4. Los otros 16 no se tocan.

**MD5 de control**

```
                antes                             después
26a9-04.bin     b8ce1f29bb973601ff5f95b3073880a0  3f5f52bd363519ca55b94293e7d58a47
26ac-0e.63      a459bd618ba87032fec636ee34e5adac  ba36cb71f1437b947bab2b50f09234f2
```

### ¿Por qué no un solo parche del zip entero?

Porque el checksum de un zip depende del nivel de compresión y del orden de
los ficheros: el mismo contenido puede dar zips distintos. Un parche hecho
contra un zip concreto fallaría con cualquier otro. Las ROMs de dentro sí son
estables, así que se parchean esas.

## Compatibilidad

Probado con **FB Alpha 2012**. Debería funcionar en cualquier emulador que
mueva el set `ddragon2`, y en hardware real: sólo cambian las ROMs de
programa, y ni su tamaño ni su disposición se alteran.

El modo de dos jugadores funciona con normalidad. Todo el código modificado
va indexado por jugador, así que ambos se comportan igual.

## Lo que no está probado

Prefiero decirlo a que salga luego:

- **Los troncos de madera.** Recogerlos con el puño está implementado y se
  comporta como cualquier otra recogida, pero no me he vuelto a cruzar con
  uno para confirmarlo en partida.
- **El agarre, el rodillazo y el lanzamiento.** El manual los describe como
  «ataque frontal» y «ataque trasero», que con este parche pasan a ser
  botones fijos como todo lo demás, pero no los he medido uno a uno.

Si alguien se anima a probarlo y encuentra algo raro, que lo diga y le meto
mano.
