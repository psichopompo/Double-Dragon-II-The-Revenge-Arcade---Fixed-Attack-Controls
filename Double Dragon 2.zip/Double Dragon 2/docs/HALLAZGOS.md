# Double Dragon II (arcade) — controles

## El encargo (David)

> «El botón de salto es siempre salto, pero los botones de puño y patada se
> alternan en función del lado al que mira el personaje. La idea es que el
> puño sea siempre puño, independientemente del lado al que mire el
> personaje, y lo mismo con la patada.»

## [HECHO] La ROM

`roms/ddragon2.zip` — MD5 `06d3a2e5d2c4172af3b61fc74c8bc29d`. Es la placa
arcade de Technōs (`ddragon2` de MAME/FBA), CPU **HD6309/6809**.

```
26a9-04.bin   32 KB   CPU principal, ROM FIJA en $8000-$FFFF   <- aqui esta todo
26aa-03.bin   32 KB   banco conmutable $4000-$7FFF
26ab-0.bin    32 KB   idem
26ac-0e.63    32 KB   sub-CPU
26a8-0e.19    64 KB   sonido
26j0-0..26j7-0, 26ae, 26af, 26a10   graficos
prom.16       512 B   PROM
```

Vectores de `26a9-04.bin`: RESET `$8000`, IRQ `$809F`, FIRQ `$8081`,
NMI `$8038`. Confirma que mapea en `$8000`.

## [HECHO] Emulador: FB Alpha 2012, el mismo que usa David

Compilado desde `github.com/libretro/fbalpha2012` (commit `0ce3153`) con
`make -f makefile.libretro`. Salida en `tools/bin/fbalpha2012_libretro.so`
(24 MB). Arnés propio en `tools/fba.py`.

Verificado: carga la ROM de David, muestra el título, se le mete moneda con
**SELECT**, se arranca con **START** y hacia el frame ~1360 hay personaje
jugable con enemigos.

**Trampa medida:** FBA **no expone la RAM** por `retro_get_memory_data`
(devuelve 0 bytes). Para inspeccionar el estado hay que usar
`retro_serialize` (savestate de 18244 B), que sí lo lleva dentro.

## ⭐ [HECHO] Dónde se leen los mandos

En `26a9-04.bin`, patrón repetido en `$8988`, `$89CA`, `$8A5F`:

```
B6 38 01   LDA $3801      ; puerto del jugador 1
43         COMA
F6 38 02   LDB $3802      ; puerto del jugador 2
53         COMB
```

`$3800` = monedas/sistema, `$3801` = P1, `$3802` = P2, `$3803`/`$3804` = DIPs.

## ⭐ [HECHO] Dónde se guarda la entrada del jugador

**Un único punto en toda la ROM** escribe el byte de entrada del jugador
(offset `+$43` de su bloque):

```
8B68  34 7E        PSHS #$7E
8B6A  17 73 4C     LBSR $FEB9        ; -> JMP $43D4 (banco conmutado)
8B6D  1F 89        TFR  ...
8B6F  84 70        ANDA #$70         ; se queda con los 3 botones
8B71  A7 88 43     STA  $43,X        ; <-- UNICA escritura de +$43
8B74  A7 E4        STA  ,S
8B76  A8 88 44     EORA $44,X        ; XOR con la entrada del frame anterior
8B79  A4 E4        ANDA ,S
8B7B  44 44 44 44  LSRA x4           ; los pasa a los bits bajos
8B7F  A7 88 40     STA  $40,X        ; +$40 = botones RECIEN pulsados
8B82  A6 E4        LDA  ,S
8B84  A7 88 44     STA  $44,X        ; +$44 = entrada de este frame
```

Máscara `$70` = bits **$10**, **$20** y **$40**: los tres botones.

## ⭐ [HECHO] Dónde se decide puño o patada

`$A2FC`, alcanzada desde una tabla de saltos por estado del jugador
(la entrada está en `$A274`):

```
A2FC  34 40        PSHS #$40
A2FE  A6 01        LDA  1,X
A300  81 02        CMPA #$02
A302  10 24 00 62  LBCC $A368
A306  A6 88 43     LDA  $43,X
A309  84 20        ANDA #$20        ; <-- BOTON $20
A30B  27 2A        BEQ  $A337
A30D  86 02        LDA  #$02
A30F  A7 88 2F     STA  $2F,X       ; accion 2
...
A31D  10 8E A5 98  LDY  #$A598      ; tabla de animacion de la accion 2
...
A337  A6 88 43     LDA  $43,X
A33A  84 10        ANDA #$10        ; <-- BOTON $10
A33C  27 28        BEQ  $A366
A33E  86 03        LDA  #$03
A340  A7 88 2F     STA  $2F,X       ; accion 3
...
A34E  10 8E A5 A7  LDY  #$A5A7      ; tabla de animacion de la accion 3
```

Las dos tablas de sprites son distintas, o sea que son dos ataques distintos:

```
$A598 (accion 2): 60 61 62 60 61 62 5F 60 61 74 75 76 7F 7F 7F
$A5A7 (accion 3): 5B 5C 5A 5B 5C 5A 62 63 5B 6F 70 6E 7F 7F 59
```

## [HIPOTESIS] Lo que falta por medir

El código de `$A2FC` **no mira la orientación**: coge el bit `$20` o el `$10`
y ya. Y `$8B71` guarda los botones **sin rotarlos**. O sea que, o bien:

- **(a)** la rotación se hace dentro de `$43D4` (banco conmutado, que aún no
  he desensamblado), o
- **(b)** no hay rotación de la *entrada*: lo que cambia es la *animación*
  que se elige después, según hacia dónde mira el personaje.

Si es (b), el arreglo sería intercambiar qué acción dispara cada bit cuando
el personaje mira a la izquierda — pero **hay que medirlo antes de tocar
nada**.

Siguiente paso: desensamblar `$43D4` en el banco conmutado y, sobre todo,
**comprobar en el emulador** qué sale por pantalla con cada botón mirando a
cada lado.

---

## ⭐ [HECHO] Mapeo de botones, MEDIDO en la RAM del juego

Método: arrancar, entrar en juego, mirar a la derecha y pulsar cada botón,
guardando el savestate. Comparando los savestates byte a byte, **sólo 2
bytes cambian** y valen exactamente lo esperado:

```
offset 997/998 del savestate     sin boton   con boton
  RetroPad B  (Fire 1)              $00        $10
  RetroPad A  (Fire 2)              $00        $20
  RetroPad Y  (Fire 3)              $00        $40
```

Y en el driver de FBA (`d_ddragon.cpp`, `DrvInputList`):

```
P1 Fire 1 -> DrvInputPort0 + 4   ->  bit $10
P1 Fire 2 -> DrvInputPort0 + 5   ->  bit $20
P1 Fire 3 -> DrvInputPort2 + 1   ->  bit $40
```

Encaja con la máscara `ANDA #$70` de `$8B6F`: los tres botones son
**$10, $20 y $40**.

### [ERROR PROPIO] Mi arnés no enviaba los botones

Durante un rato las pruebas daban «el juego no responde a ningún botón»
porque mi callback de entrada devolvía 1 para *cualquier* id pulsado. Al
pedir FBA el estado de varios ids, el core veía todos los botones pulsados a
la vez y el juego no hacía nada coherente. Además, la escena avanza sola
(los enemigos entran), así que comparar capturas separadas por segundos
mezclaba el efecto del botón con el avance del nivel.

Lo cazó una **prueba de control**: comparar «sin pulsar nada» contra cada
botón con la misma semilla. Daban firmas idénticas, lo que era imposible si
el botón llegara.

## ⭐ [HECHO] Dónde se rota el ataque según el lado

`$97B2`, dentro de la rutina de estado del jugador:

```
97B2  A6 88 43   LDA  $43,X
97B5  84 50      ANDA #$50      ; ¿alguno de los DOS ataques? ($10 o $40)
97B7  27 2A      BEQ  $97E3
97B9  EC 0F      LDD  15,X      ; velocidad/posicion X con signo
97BB  27 12      BEQ  $97CF
97BD  2A 09      BPL  $97C8     ; segun el SIGNO -> mira a un lado u otro
97BF  A6 88 43   LDA  $43,X
97C2  84 10      ANDA #$10      ;   rama "mira a la izquierda": mira el $10
97C4  27 1D      BEQ  $97E3
97C6  20 07      BRA  $97CF
97C8  A6 88 43   LDA  $43,X
97CB  84 40      ANDA #$40      ;   rama "mira a la derecha": mira el $40
97CD  27 14      BEQ  $97E3
97CF  A6 88 43   LDA  $43,X
97D2  5F         CLRB
97D3  84 10      ANDA #$10
97D5  27 02      BEQ  $97D9
97D7  C6 80      LDB  #$80      ; <-- FLIP del sprite
97D9  E7 03      STB  3,X       ;     +$3 = atributo de volteo
```

**Aquí está el corazón del sistema de David**: el bit `$10` no significa
«puño», significa **«atacar hacia la izquierda»**, y de hecho *fuerza el
volteo del sprite* (`LDB #$80` / `STB 3,X`). El `$40` es «atacar hacia la
derecha».

## ⭐ [HECHO] El mecanismo, ya claro

Juntando las tres piezas medidas:

```
$8B6F  ANDA #$70    la entrada guarda los 3 botones SIN rotar:  $10 $20 $40
$97B5  ANDA #$50    ¿hay ataque?  -> mira SOLO $10 y $40 (los dos de ataque)
$97BD  BPL          segun el signo de +$15 (hacia donde mira) elige rama:
         rama izquierda -> ANDA #$10
         rama derecha   -> ANDA #$40
$97D7  LDB #$80     si el boton pulsado es $10, FUERZA el volteo del sprite
$A309  ANDA #$20 -> accion 2 (tabla $A598)
$A33A  ANDA #$10 -> accion 3 (tabla $A5A7)
```

O sea, **exactamente lo que describe David**: los bits `$10` y `$40` no son
«puño» y «patada», son **«ataca hacia la izquierda»** y **«ataca hacia la
derecha»**. El juego decide *qué animación* sale según coincida o no con el
lado al que ya miras: si atacas hacia donde miras sale el golpe frontal
(puño), y si atacas hacia atrás sale la coz.

## [ABIERTO] Lo que falta antes de tocar nada

Las pruebas en pantalla no acaban de aislar la animación porque:

- la escena avanza sola (entran enemigos), así que dos capturas separadas
  no son comparables;
- `load_state` del core **dice True pero no restaura** (medido: la firma de
  pantalla no cambia tras cargarlo), así que no puedo repetir el mismo
  instante. Hay que relanzar el emulador entero por cada prueba.
- sin enemigo delante, el personaje apenas cambia de estado y el savestate
  sólo difiere en 1 byte.

**Lo que hace falta:** un savestate de David (o de RetroArch con este mismo
core) con el personaje **plantado delante de un enemigo**, para poder
disparar el ataque y ver la animación limpia. Con eso se confirma en dos
minutos qué animación sale con cada bit y a cada lado.

---

## ⭐⭐ [HECHO] Los states de David lo confirman TODO (2026-09-05)

Cuatro savestates de RetroArch, uno por caso. Formato: RZIP (zlib desde el
offset 24) y, ya descomprimido, cabecera **`RASTATE`** + bloque **`MEM `**
con el tamaño en LE32. Los datos del core empiezan en el **offset 16** y
miden 18244 B, exactamente lo que devuelve `retro_serialize`. Cargan bien
(cuatro firmas de pantalla distintas).

**Lo mejor: los states traen el botón pulsado grabado dentro.** Leyendo el
byte de entrada (offsets 997/998 del savestate):

```
Billy punch right      -> $40      <-- PUÑO mirando a la derecha
Billy kick back right  -> $10      <-- COZ  mirando a la derecha
Billy punch left       -> $00      (capturado un frame despues del golpe)
Billy kick back left   -> $00      (idem)
```

Esto **cierra la duda de una vez**, y además corrige una suposición mía:

- **`$40` NO es el salto en el sentido que yo pensaba.** Es el botón que,
  mirando a la **derecha**, da el **puño**.
- **`$10`** es el que, mirando a la derecha, da la **coz hacia atrás**.

Concuerda exactamente con el código de `$97B2`:

```
$97BD  BPL   -> segun el signo de +$15 (hacia donde mira Billy)
   rama "mira a la IZQUIERDA":  el ataque valido es  ANDA #$10
   rama "mira a la DERECHA"  :  el ataque valido es  ANDA #$40
$97D7  LDB #$80  -> si el boton es $10, FUERZA el volteo del sprite
```

Es decir: **`$10` = «pega hacia la izquierda»** y **`$40` = «pega hacia la
derecha»**, tal cual describió David. Cuando pegas hacia donde ya miras sale
el puño; cuando pegas hacia el lado contrario, el juego te gira (`LDB #$80`)
y sale la coz.

El tercero, **`$20`**, es el **salto** (comprobado en pantalla: Billy se
eleva).

### Resumen del mapeo, ya sin hipótesis

```
bit $10   "ataca a la IZQUIERDA"   (Fire 1, RetroPad B)
bit $20   SALTO                    (Fire 2, RetroPad A)
bit $40   "ataca a la DERECHA"     (Fire 3, RetroPad Y)
```

### Lo que hay que cambiar

Que el botón sea siempre la misma **acción** en vez del mismo **lado**:

- `$10` -> siempre **puño** (golpe frontal, hacia donde mire)
- `$40` -> siempre **patada**
- `$20` -> salto, sin tocar

El punto exacto es `$97B2`-`$97D9`, que es justo la rutina que elige rama
según la orientación y que fuerza el volteo. Es un bloque pequeño y aislado.

**Pendiente antes de tocar nada:** decidir con David qué botón quiere para
puño y cuál para patada, porque el arreglo fija esa asignación.

---

## [HECHO] Infraestructura de parcheo (2026-09-05)

`tools/build.py` reempaqueta el zip con `26a9-04.bin` parcheado.

**Trampa medida:** FBA identifica el juego por el **NOMBRE del fichero**. Un
zip con contenido idéntico pero llamado `t_igual.zip` hace fallar
`retro_load_game`. El destino tiene que llamarse **`ddragon2.zip`** (en otra
carpeta). Lo cazó una prueba de control: reempaquetar SIN cambios y ver si
cargaba — no cargaba, luego no era culpa del parche.

**Prueba de control del parcheo** (que el cambio llega de verdad):

```
poner RTS en el vector RESET ($8000, ROM 0x0000)
  original  cbeb139f
  RTS       638817ca      <-- la pantalla CAMBIA: el parche SI se aplica
```

## ⭐ [ERROR PROPIO] `$97B2` y `$A2FC` NO son del jugador

Puse un `RTS` al principio de cada una y **la pantalla no cambia en
absoluto**, ni cargando los states de David ni jugando normal:

```
$97B2 = RTS   ->  sin diferencia (0 px) en todos los casos probados
$A2FC = RTS   ->  sin diferencia
```

Y el parcheo funciona (probado con el RESET). O sea que esas rutinas **no se
ejecutan** para el personaje del jugador: serán de los enemigos, del
jugador 2, o de un modo que no estoy tocando.

Todo el análisis estático de las entradas anteriores (el `ANDA #$50`, el
`BPL` según orientación, el `LDB #$80` del volteo) describe correctamente
*una* rutina con esa lógica, pero **no la que mueve a Billy**. Encaja
demasiado bien con lo que describe David como para ser casualidad: lo más
probable es que sea la versión de esa misma lógica para otro actor, y que la
del jugador esté en el **banco conmutable** (`$4000-$7FFF`), que es donde
apuntaba `LBSR $FEB9` -> `JMP $43D4`.

**Lección:** localizar código por patrón estático no basta. Hay que
**confirmar con un RTS o un breakpoint que esa rutina se ejecuta** antes de
construir nada encima. Me ahorra el error de diseñar un parche sobre código
muerto.

## Siguiente paso

Desensamblar el banco conmutable. `26aa-03.bin` / `26ab-0.bin` / `26ac-0e.63`
mapean en `$4000-$7FFF` (16 KB por banco, seleccionables), y `$43D4` cae
justo ahí. Buscar la lógica equivalente y **verificarla con RTS** antes de
tocar nada.

## [HECHO] Cómo probar con los states (receta que SÍ funciona)

Dos cosas que costaron rato y hay que respetar:

1. **Dejar pasar ~20 frames tras cargar el state antes de pulsar.** El state
   está capturado en mitad de una animación de golpe, y mientras dura, el
   juego **ignora la entrada**. Medido:

```
   sin espera   : $10 y $40 dan EXACTAMENTE la misma pantalla que no pulsar
   espera 20 f  : $10 y $40 dan pantallas DISTINTAS entre si y de "nada"
   espera 40 f  : vuelve a no responder (esta en otra animacion)
```

   Durante un rato interpreté ese "no responde" como que el parche no hacía
   efecto. **No era el parche: era que el juego no aceptaba entrada.**

2. **Una sola instancia de FBA por proceso.** Crear dos `FBA()` en el mismo
   script revienta con `double free or corruption`. Igual que en el proyecto
   Momotaro con el core de PC Engine (norma 378). Para comparar A contra B
   hay que lanzar un proceso por caso.

Verificado que los botones SÍ llegan al juego con el state cargado, leyendo
el propio savestate tras pulsar:

```
   sin boton -> off997 = $00
   Fire1 (B) -> off997 = $10
   Fire3 (Y) -> off997 = $40
```

---

## ⭐⭐ [HECHO] LA RUTINA DEL JUGADOR SÍ ES `$8B6F`. Parche v1 (2026-09-05)

### La prueba de causalidad que lo confirma

Descartadas `$97B2` y `$A2FC` con el `RTS`, probé el otro punto: la máscara
de botones de `$8B6F`.

```
$8B70   ANDA #$70  ->  ANDA #$00     (borra los 3 botones)
   con el state 'punch right' + espera 20 f + Fire3:
   original  ... 8ce103 8ce103 80277c aa9d37
   parcheado ... d21c5b d21c5b ac0517 468355   <-- CAMBIA
```

Y aislando cada bit (`ANDA #$10` / `#$20` / `#$40`), cada máscara reproduce
exactamente el comportamiento del botón correspondiente. **`$8B6F` es la
ruta del jugador**, sin ninguna duda.

### El parche

Idea: no tocar la lógica de «ataca a la izquierda / a la derecha». Basta con
**intercambiar los bits `$10` y `$40` cuando Billy mira a la izquierda**.
Así el botón mantiene su *acción* en vez de su *lado*.

La orientación se lee de `+$3` del bloque de jugador (el atributo de volteo
del sprite: bit 7 = mirando a la izquierda), que es justo lo que escribe
`$97D9`.

```
$8B71   A7 88 43     STA $43,X   ->   BD FB B2   JSR $FBB2
```

Y en el relleno de `$FBB2` (78 bytes libres, se usan 30):

```
FBB2  34 04        PSHS B
FBB4  E6 03        LDB  3,X       ; flip del sprite
FBB6  2A 12        BPL  $FBCA     ; mira a la derecha -> no tocar
FBB8  34 02        PSHS A
FBBA  84 50        ANDA #$50      ; aislar los dos bits de ataque
FBBC  27 0A        BEQ  $FBC8     ; ninguno -> no tocar
FBBE  81 50        CMPA #$50      ; ¿los dos a la vez?
FBC0  27 06        BEQ  $FBC8     ; -> no tocar
FBC2  35 02        PULS A
FBC4  88 50        EORA #$50      ; intercambia $10 <-> $40
FBC6  20 02        BRA  $FBCA
FBC8  35 02        PULS A
FBCA  35 04        PULS B
FBCC  A7 88 43     STA  $43,X     ; el STA que hemos desplazado
FBCF  39           RTS
```

Verificada la tabla de verdad de las 16 combinaciones antes de tocar la ROM:

```
A     mira DERECHA   mira IZQUIERDA
$10      $10             $40      <- Fire1 se convierte en "ataca derecha"
$20      $20             $20      <- el SALTO nunca se toca
$40      $40             $10
$50      $50             $50      <- los dos a la vez: sin cambio
$30      $30             $60      <- salto + ataque: se respeta el salto
```

### Verificación en el emulador

Cargando `punch right`, girando a la izquierda con LEFT y atacando:

```
            frames 5..8 de la animacion
original Fire1   9bd306 30e75d e1cffa 97e257
PARCHE   Fire1   05356a 298ed2 821a3d 4c96c7   <-- ahora hace lo de Fire3
original Fire3   05356a 298ed2 821a3d 4c96c7
PARCHE   Fire3   9bd306 30e75d e1cffa 97e257   <-- ahora hace lo de Fire1
```

**Intercambio exacto y simétrico.** Mirando a la derecha, los cuatro casos
dan resultados idénticos al original (correcto: ahí no hay que tocar nada).

No-regresión: arranque, pantalla de atracción y entrada al juego dan las
mismas firmas que la ROM original en los frames 300/600/900/1100.

### Entrega

```
roms/v1/ddragon2.zip   MD5 2d1822cd8619d58f721e4fa2d3f47826
33 bytes cambiados, todos en 26a9-04.bin
```

---

## [ERROR PROPIO] La v1 estaba invertida: parcheaba el lado equivocado

David probó `roms/v1/ddragon2.zip` y **no notó ningún cambio**. Tenía razón:
el parche estaba puesto del revés.

### Qué falló en mi razonamiento

Di por supuesto que el juego "de fábrica" hace **puño mirando a la derecha**
y **coz mirando a la izquierda**, porque así lo decían los nombres de los
`.state` de David. De ahí saqué que había que intercambiar los bits *cuando
mira a la izquierda*, y escribí `BPL $FBCA` = "si mira a la derecha, no
tocar".

Lo medido en partida real dice lo contrario:

```
ORIGINAL, mirando DERECHA (flip=$00):   Fire1 (B) = COZ hacia atrás
                                        Fire3 (Y) = PUÑO al frente
ORIGINAL, mirando IZQUIERDA (flip=$80): Fire1 (B) = PUÑO al frente
                                        Fire3 (Y) = COZ hacia atrás
```

O sea que la rama que había que corregir era **flip=$00**, no **flip=$80**.
Mi v1 tocaba justo el lado que ya estaba bien y dejaba intacto el que
fallaba. Por eso las firmas "intercambiaban" limpiamente en mi banco de
pruebas y aun así en el mando no se notaba nada: el intercambio se aplicaba
al caso que no había que tocar.

### [ERROR PROPIO] Por qué mi verificación de la v1 dio "correcto"

Dos fallos encadenados en el método, no en la ROM:

1. **Los cuatro `.state` de David no cargan.** Los cuatro producen
   **exactamente la misma imagen**, y es la **pantalla de título**
   (MD5 `39b0b803268337ddb842ad98e45c6d3f` en los cuatro). `retro_unserialize`
   devuelve `true` pero no restaura nada. Estuve midiendo animaciones de
   combate sobre la pantalla de título.
2. **El offset del bloque de jugador estaba mal.** Usé `997-$43`, deducido
   de esos states muertos. Medido en partida real por diferencia de
   savestates (sin botón / Fire1 / Fire3), el byte de entrada `+$43` está en
   el offset **`0x3E5`**, o sea el bloque empieza en **`0x3A2`**:

```
   offset 0x3E5/0x3E6 = entrada del jugador     ($10 con B, $40 con Y)
   offset 0x3A2+$03   = flip del sprite          ($00 derecha, $80 izquierda)
```

   Con el offset viejo leía `+$2F` y salía siempre `$00`: no era la acción.

Norma nueva: **459 — un savestate que "carga" pero deja la misma imagen en
todos los casos no ha cargado. Cotejar SIEMPRE una captura antes de medir
sobre él.**

### Escenario de prueba válido (medido)

Nada de states. Partida desde cero dentro del propio arnés:

```
run(200) · SELECT · SELECT · START · run(900)
toque de LEFT/RIGHT 8 frames · run(50) para quedar quieto
botón 6 frames · capturar 20 frames
```

Control de que la ruta es la del jugador: `ANDA #$00` en `$8B70` deja al
personaje sin atacar. **Confirmado en partida real**, así que `$8B71` sigue
siendo el punto bueno.

## ⭐ [HECHO] v2 — un solo byte de diferencia con la v1

```
0x07BB6   2A 12   BPL $FBCA   ->   2B 12   BMI $FBCA
```

"Si mira a la IZQUIERDA, no tocar." El resto de la rutina es idéntico.

Tabla de verdad de la v2:

```
A     mira DERECHA($00)   mira IZQUIERDA($80)
$10        $40                  $10
$20        $20                  $20     <- salto intacto en los dos lados
$40        $10                  $40
$50        $50                  $50     <- los dos ataques: sin cambio
$30        $60                  $30     <- salto+ataque: respeta el salto
```

### Verificación en pantalla, partida real

```
                        frames 02..07 de la animación
ORIG  DERECHA   Fire1   34ed89 9a47d1 9a47d1 0bb5a4 cb42ef ea89ff   (coz)
V2    DERECHA   Fire1   39ccbf 0b3c1d c81d40 40d39c 40d39c ce07da   (puño) <-- cambia
ORIG  DERECHA   Fire3   39ccbf 0b3c1d c81d40 40d39c 40d39c ce07da   (puño)
V2    DERECHA   Fire3   34ed89 9a47d1 9a47d1 0bb5a4 cb42ef ea89ff   (coz)  <-- cambia

ORIG  IZQUIERDA Fire1   80ba8c 80e76f 66986f eed9ae eed9ae 8da5a2   (puño)
V2    IZQUIERDA Fire1   80ba8c 80e76f 66986f eed9ae eed9ae 8da5a2   IDÉNTICO <-- correcto
ORIG  IZQUIERDA Fire3   6605ea 13577d 13577d 883f03 0bbf6b 0c6d37   (coz)
V2    IZQUIERDA Fire3   6605ea 13577d 13577d 883f03 0bbf6b 0c6d37   IDÉNTICO <-- correcto
```

Resultado: **Fire1 = PUÑO y Fire3 = PATADA en los dos lados**, que es lo que
pidió David.

Comprobado además que la v1 hacía exactamente lo contrario: sus firmas
mirando a la izquierda sí cambiaban (y no debían) y mirando a la derecha
eran idénticas al original (y debían cambiar).

### Salto y no-regresión

```
Salto (Fire2/A), mirando derecha:  ORIG y V2 dan las 20 firmas IDÉNTICAS.
Los dos ataques a la vez (B+Y):    ORIG y V2 IDÉNTICOS.
Atracción, frames 200/400/700/1000: IDÉNTICOS a la ROM original.
```

Los frames 1300/1600 divergen, pero **no es regresión**: es la demo de
atracción, que ahí ya está jugando sola con los botones y por tanto los usa
intercambiados. Comprobado en la captura: misma pantalla, mismos enemigos,
sólo cambia la animación del personaje de la demo.

### Entrega

```
roms/v2/ddragon2.zip   MD5 79aaae25d8440b159af10c22af2adc50
34 bytes cambiados en 26a9-04.bin (los 33 de la v1 + el BPL->BMI)
```

`roms/v1/ddragon2.zip` queda **retirada** (norma: borrar las ROMs con bugs).

---

## [ERROR PROPIO] El bucle de giro en el aire lo causaba mi parche

David: «cuando pulsamos salto y patada a la vez, el jugador mira en bucle de
derecha a izquierda estando en el aire».

Reproducido en la v2 (mirando a la derecha, salto + Fire3, un frame por línea):

```
f06 flip=80 in=10    f07 flip=80 in=40    f08 flip=00 in=40    f09 flip=00 in=10
f10 flip=80 in=10    f11 flip=80 in=40    f12 flip=00 in=40    f13 flip=00 in=10
```

Periodo 4. En la ROM original ese mismo caso da `flip` **constante**.

### Qué falló en mi razonamiento

Leía la orientación de `+$03`, el atributo de volteo del sprite. **`+$03` no
es una entrada, es una SALIDA**: la rutina `$97CF` lo *escribe* según el bit
`$10` (`LDB #$80` / `STB 3,X`). O sea:

```
mi parche lee +$03  ->  cambia el bit de entrada  ->  el juego escribe +$03
        ^-------------------------------------------------------|
```

Un lazo de realimentación. En el suelo no se nota porque otra cosa fija el
flip cada frame; en el aire nada lo sujeta y oscila con periodo 4.

Es el mismo tipo de fallo que el de la v1: **di por buena una fuente de datos
sin comprobar quién más la escribe.**

Norma nueva: **460 — antes de leer un byte para decidir, comprobar si ese
byte lo escribe el propio código que vas a modificar. Una salida no sirve
como entrada.**

### La fuente de orientación buena

Medida por diferencia de bloques (reposo derecha vs reposo izquierda) y luego
por estabilidad durante el ataque aéreo:

```
offset   der   izq   ¿estable en el aire?
 +$02    05    85    NO (mezcla estado de animación)
 +$03    00    80    NO  <- el que usaba, es SALIDA
 +$05    63    43    SÍ   <- bit $20 = mira a la derecha
 +$38    63    43    SÍ   (copia)
```

`+$05` bit `$20` se mantiene constante durante todo el salto y todo el
ataque, en los dos sentidos. Es la orientación real.

## ⭐ [HECHO] v3 — lee `+$05` en vez de `+$03`

```
FBB2  34 04        PSHS B
FBB4  E6 05        LDB  5,X       ; orientacion REAL
FBB6  C5 20        BITB #$20
FBB8  27 12        BEQ  $FBCC     ; mira izquierda -> no tocar
FBBA  34 02        PSHS A
FBBC  84 50        ANDA #$50
FBBE  27 0A        BEQ  $FBCA
FBC0  81 50        CMPA #$50
FBC2  27 06        BEQ  $FBCA
FBC4  35 02        PULS A
FBC6  88 50        EORA #$50
FBC8  20 02        BRA  $FBCC
FBCA  35 02        PULS A
FBCC  35 04        PULS B
FBCE  A7 88 43     STA  $43,X
FBD1  39           RTS
```

32 bytes en `$FBB2` (78 libres) + el `JSR` en `$8B71`.

### Verificación

Suelo, los cuatro casos: idéntico a la v2 (Fire1 puño, Fire3 patada, los dos
lados). Aire: **`flip` constante en los cuatro casos**, bucle eliminado.

```
v3 aire DER Fire1  flip=00 constante
v3 aire DER Fire3  flip=80 constante   <- ver nota abajo
v3 aire IZQ Fire1  flip=80 constante
v3 aire IZQ Fire3  flip=00 constante
```

No-regresión: atracción idéntica al original hasta el frame **1300**
(la v2 divergía ya en 1300). Salto solo y los dos botones a la vez: idénticos.

### [PENDIENTE] El giro único que queda en el aire

En la v3 el flip ya no oscila, pero al atacar en el aire con el botón que
"pertenece" al otro lado el personaje **se da la vuelta una vez** y se queda
así. Eso **también pasa en la ROM ORIGINAL**: medido con retardos 2, 6, 10,
14, 18 y 22 desde el inicio del salto, la original con Fire1 mirando a la
derecha da `flip=80` en todos. Es el comportamiento de fábrica: la patada
voladora se orienta hacia donde ataca.

No lo he tocado porque hacerlo cambia la *dirección del ataque*, no sólo la
animación, y eso lo decide David.

## [HECHO] Sobre el huracán y el reparto de botones en el aire

Medido en la ROM ORIGINAL, mirando a la derecha, variando el frame en que se
pulsa el botón (retardo desde el salto): con `Fire1` y con `Fire3` salen dos
animaciones **distintas** en todos los retardos probados (2..22), pero
**ninguna de las dos cambia al llegar al punto más alto** (el vértice está
sobre el frame 22-24 según el byte de altura `+$09`, que sube hasta `$37` y
baja).

O sea: en esta placa **no he encontrado que el huracán dependa del instante
del salto**. Los dos ataques aéreos son dos movimientos fijos, uno por botón.
Falta identificar cuál es cuál en pantalla antes de decidir el reparto.

---

# LA CAUSA RAÍZ (tras el informe de David sobre la v3)

David: «muchas veces el puñetazo da la coz... A veces, simplemente con estar
parado mirando a la izquierda, al pulsar el puño, da la coz... Yo creo que la
rutina que implementaste en la primera versión no era quizás la correcta.»

Tenía razón otra vez. Y el fallo es de **diseño**, no de un byte.

## [ERROR PROPIO] #1: el experimento de control de la v1 era INVÁLIDO

En su día descarté `$97B2` y `$A2FC` poniéndoles un `RTS` y viendo que «la
pantalla no cambia». **Esa prueba la hice sobre los `.state` de David, que no
cargan** (dan la pantalla de título). Estaba comparando pantallas de título.

Rehecha ahora en partida real, con el escenario válido:

```
                        +$02 (código de sprite), mirando derecha + Fire1
ORIGINAL                05 05 73 73 73 73 74 74 74 74 74
RTS en $97B2            05 05 73 73 73 73 74 74 74 74 74   idéntico
RTS en $A2FC            05 05 73 73 73 73 74 74 74 74 74   idéntico
RTS en $AC60            05 05 73 73 73 73 74 74 74 74 74   idéntico
```

O sea: el veredicto era correcto por casualidad, pero la prueba no valía.
Norma 450 (experimento de control) aplicada sobre datos muertos no es un
control. **Toda conclusión sacada con esos states hay que rehacerla.**

## ⭐ [HECHO] #2: los códigos de animación, medidos en partida real

```
                 +$02 en reposo -> durante el golpe
mirando DERECHA   05  ->  Fire1: 73 74    Fire3: 12 13 14
mirando IZQUIERDA 85  ->  Fire1: 92 93 94  Fire3: F3 F4
```

El bit `$80` de `+$02` es el volteo. Quitándolo:

```
              Fire1      Fire3
DERECHA       73 74      12 13 14
IZQUIERDA     12 13 14   73 74
```

**`12 13 14` es el PUÑETAZO y `73 74` es la COZ**, y efectivamente el juego
los cruza según el lado. Confirmado con la tabla de animación en `$AD2F`
(`12 13 14`) que usa la rutina de combo `$AC60`.

## ⭐⭐ [HECHO] #3: LA CAUSA DE LOS CONFLICTOS — nivel contra flanco

Esto es lo que explica todo lo que describe David. El código de `$8B71`:

```
8B71  A7 88 43     STA  $43,X    ; +$43 = NIVEL (botón mantenido)  <- MI PARCHE ESCRIBE AQUÍ
8B74  A7 E4        STA  ,S
8B76  A8 88 44     EORA $44,X    ; XOR con el frame anterior
8B79  A4 E4        ANDA ,S       ; deja sólo los bits que pasaron de 0 a 1
8B7B  44 44 44 44  LSRA x4
8B7F  A7 88 40     STA  $40,X    ; +$40 = FLANCO (recién pulsados) >>4
8B84  A7 88 44     STA  $44,X    ; +$44 = memoria del frame anterior
```

**Hay DOS bytes de entrada, no uno:**

```
+$43  NIVEL   botones mantenidos     ($10/$20/$40)
+$40  FLANCO  recién pulsados, >>4   ($01/$02/$04)
```

Mi parche intercambia los bits **antes** del cálculo del flanco, así que el
flanco también sale intercambiado... pero `+$44` (la memoria del frame
anterior) guarda el valor **ya intercambiado**. En el frame en que el
personaje **cambia de orientación** mientras mantienes el botón, el valor
intercambiado cambia de golpe sin que tú hayas soltado nada:

```
frame N    miras derecha, pulsas Fire1 -> +$43 = $40   +$44 = $40
frame N+1  te giras a la izquierda     -> +$43 = $10   +$44 = $40
                                          EORA -> $50, ANDA -> $10
                                          ¡FLANCO FALSO de $10 sin soltar el botón!
```

**Eso es exactamente lo que ve David**: golpes que salen solos, el puño que
da coz, la coz que da puño, y sospecha (acertada) de que el direccional está
metido en el ajo. El direccional cambia la orientación, la orientación cambia
el bit que escribo, y el cambio de bit fabrica un flanco falso.

Medido: con la entrada **fija** (`LDA #$10` / `LDA #$40` permanente) el
personaje **no ataca nunca**, en ninguno de los dos lados. Confirma que el
juego dispara los golpes por **flanco**, no por nivel.

## ⭐ [HECHO] #4: la v3 no hacía nada mirando a la izquierda

```
                 +$43              +$40           +$02
ORIG  IZQ Fire1  00 10 10 10 10    00 01 00 00    85 85 92 92 93
V3    IZQ Fire1  00 10 10 10 10    00 01 00 00    85 85 92 92 93   IDÉNTICO
```

Correcto por diseño: la v3 sólo tocaba la rama «mirando a la derecha». Pero
significa que mirando a la izquierda seguía el comportamiento de fábrica
(Fire1 = puño porque el juego ya lo cruza), y al girarse se generaba el
flanco falso. De ahí la incoherencia intermitente.

## Conclusión: el enfoque de intercambiar bits está MAL DE ORIGEN

David lo ha clavado:

> «Quizá deberíamos limpiar todas las asociaciones de puño y patada y asignar
> una sola a cada cosa.»

Es lo correcto. Intercambiar bits de entrada es luchar contra el sistema:
el bit `$10` no significa «puño», significa «atacar hacia la izquierda», y
además **fuerza el volteo del sprite** (`$97D7 LDB #$80 / STB 3,X`). Mientras
el significado siga siendo direccional, cualquier intercambio arrastra el
volteo y el flanco.

**El arreglo correcto va en la SELECCIÓN DE ANIMACIÓN, no en la entrada.** Es
decir: dejar la entrada intacta (flanco, volteo y direccionalidad de fábrica,
todo sano) y hacer que el golpe *frontal* use siempre la animación y el daño
del puñetazo, y el *trasero* los de la coz. Eso es literalmente «una sola
asociación por botón».

Pendiente de localizar: el punto donde se elige entre la tabla `$AD2F`
(`12 13 14`, puñetazo) y la de la coz (`73 74`). `$AC60` es la rutina de
combo pero su `RTS` no altera el resultado, así que la selección ocurre
antes, probablemente en el **banco conmutable**: `26ac-0e.63` tiene
`LDA $43,X` en `$A4BA` y `$A4C7`, y `26ab-0.bin` tiene `LDA $40,X` en `$ACDE`.
Ahí es donde hay que mirar.

---

# ⭐⭐ LOCALIZADA LA ELECCIÓN DE ANIMACIÓN — v8

## La cadena completa, medida

```
$8B71  STA $43,X       +$43 = NIVEL de botones ($10/$20/$40)
$8B7F  STA $40,X       +$40 = FLANCO, >>4 ($01/$02/$04). DURA UN SOLO FRAME
$8F2C  STA $1E,X       +$1E = ACCION elegida   <-- EL PUNTO DE DECISION
$9630  LDA $1E,X
$9639  ASLA
$963A  LDY #$9640
$963E  JMP [A,Y]       despachador por accion
```

Tabla de punteros de acciones en **`$9640`**:

```
idx 0 -> $966C   PUÑETAZO   (tabla de sprites $96F2: 12 02 13 03 14 03 ...)
idx 1 -> $9704   COZ        (tabla de sprites $9747: 73 03 74 05 73 03 ...)
idx 2 -> $9759   salto
...
```

Verificado por control, uno a uno:

- Cambiar `$96F2` (`12`->`21`): la animación del puño cambia en pantalla.
- Cambiar `$9747` (`73`->`20`): la animación de la coz cambia en pantalla.
- Intercambiar las dos entradas de `$9640`: puño y coz se cambian.
- Forzar `+$1E` a 0/1/2/3 en `$8F2C`: sale puño / coz / salto / otra.

## Tabla de fábrica (medida en partida real)

```
              +$1E    animación
DER Fire1      01     73 74      COZ
DER Fire3      00     12 13 14   PUÑO
IZQ Fire1      00     92 93 94   PUÑO
IZQ Fire3      01     F3 F4      COZ
```

## [ERROR PROPIO] Tres intentos fallidos antes de acertar

**v4**: calculé los desplazamientos de las ramas a mano y el `BCC` cayó en
`LDA #$01` en vez de en el `STA`. Además saltaba el `PSHS B` pero ejecutaba
el `PULS B`: **pila desbalanceada**. Dos bugs en 29 bytes.

**v5/v6**: leí el botón de `+$40` (flanco) y luego de `+$43` (nivel) dentro
del gancho de `$8F2C`. Medido: `+$1E` se escribe **dos frames después** del
flanco, cuando `+$40` ya vale `00`; y en el caso IZQ+Fire1 hasta `+$43` llega
ya a `00`. **La información del botón no está disponible en ese punto.**

Norma nueva: **461 — no calcular desplazamientos de ramas a mano. Usar
`tools/asm6809.py`, que ensambla con etiquetas.**

Norma nueva: **462 — antes de leer un byte en un gancho, medir QUÉ VALE en
ese punto exacto, no en el frame del evento. Un valor puede haberse
consumido ya.**

## [ERROR PROPIO] Mi banco de pruebas medía sobre un personaje en movimiento

Usaba «girar 8 frames y esperar 50». Con esperas de 50/60/70/80 salían
resultados **distintos con la misma ROM**, y llegué a creer que la v5 era
intermitente. No lo era: el personaje seguía desplazándose y el estado no
era el mismo. `tools/reposo.py` ahora **detecta el reposo real** (espera a
que `+$1E`, `+$02`, la posición y `+$1B` no cambien en 20 frames seguidos).
Con eso el original es 100% determinista.

Norma nueva: **463 — no medir con una espera fija. Detectar el reposo por
estabilidad del estado.**

## ⭐ La solución (v8): recordar el botón en el frame del flanco

Dos ganchos:

```
$8B71  STA $43,X  ->  JSR $FBB2      (gancho 1)
$8F2C  STA $1E,X  ->  JSR $FBD0      (gancho 2)

FBB2  A7 88 43     STA  $43,X        ; la original desplazada
      34 02        PSHS A
      84 50        ANDA #$50         ; ¿hay botón de ataque?
      27 03        BEQ  fin
      A7 88 27     STA  $27,X        ; RECUERDA cuál ($10 o $40)
fin:  35 02        PULS A
      39           RTS

FBD0  81 02        CMPA #$02         ; sólo acciones 0 (puño) y 1 (coz)
      24 1E        BCC  escribe
      34 04        PSHS B
      E6 88 27     LDB  $27,X        ; el botón recordado
      C5 10        BITB #$10
      27 04        BEQ  es3
      86 00        LDA  #$00
      20 06        BRA  orient
es3:  C5 40        BITB #$40
      27 0B        BEQ  sal
      86 01        LDA  #$01
orient: E6 88 05   LDB  $05,X        ; orientación real (bit $20 = derecha)
      C5 20        BITB #$20
      26 02        BNE  sal
      88 01        EORA #$01         ; a la izquierda el juego ya cruzó el bit
sal:  35 04        PULS B
escribe: A7 88 1E  STA  $1E,X
      39           RTS
```

`+$27` es un byte **libre** del bloque de jugador: verificado que ningún
opcode indexado de las 4 ROMs de CPU lo usa, y medido que vale `00` durante
toda una partida con movimiento, ataques y saltos.

**No se toca la entrada**: el flanco, el volteo y la direccionalidad siguen
siendo los de fábrica. Sólo se reescribe la ACCIÓN ya elegida. Es lo que
pedía David: una sola asociación por botón.

## Verificación de la v8

```
              +$1E   animación        antes
DER Fire1      00    12 13 14 PUÑO    era COZ    <- cambiado
DER Fire3      01    73 74    COZ     era PUÑO   <- cambiado
IZQ Fire1      00    92 93 94 PUÑO    ya era PUÑO
IZQ Fire3      01    F3 F4    COZ     ya era COZ
```

**Manteniendo el ataque mientras se gira** (el caso que rompía v1/v2/v3),
34 frames girando de un lado a otro:

```
RIGHT->LEFT  Fire1   1E: 0000000000...0000   constante
LEFT ->RIGHT Fire1   1E: 0000000000...0000   constante
RIGHT->LEFT  Fire3   1E: 0001010101...0101   constante
LEFT ->RIGHT Fire3   1E: 0001010101...0101   constante
```

Cero flancos falsos, cero cruces.

**En el aire**: el flip cambia una vez y se estabiliza, igual que el
original. No hay bucle de giro.

**Salto**: acción `02` idéntica al original.
**Atracción**: idéntica al original hasta el frame 1300.

```
roms/v8/ddragon2.zip   MD5 e6f43798dcf63a9deccf5642e56e67cc
```

---

# [ERROR PROPIO] La v8 fallaba: +$05 NO era la orientación

David: «sigue haciendo lo que le da la gana. Unas veces da puño y otras da
coces, con ambos botones».

Tenía razón. Y el fallo tiene dos partes: el parche y, sobre todo, **cómo lo
verificaba**.

## Qué falló en la verificación (lo importante)

He entregado **cuatro** ROMs dando por buenas mediciones que no valían.
El defecto común: **medía UN golpe, desde reposo, en cuatro situaciones**.
David juega moviéndose, encadenando y saltando. Mi banco de pruebas no podía
ver el fallo porque nunca ponía al juego en la situación que lo produce.

La herramienta que faltaba: `tools/estres.py`. Juega **3000 frames con
entradas aleatorias** (direcciones, ataques, saltos, combinaciones) y
comprueba **en cada golpe** que la acción elegida corresponde al botón.
Resultado:

```
                 golpes   violaciones
ORIGINAL            27         16       (el bug de fábrica)
v8                  26         14       <- ¡mi parche apenas cambiaba nada!
```

Con eso el fallo salta en 6 segundos. Mis pruebas anteriores daban «perfecto»
sobre las mismas ROMs.

Norma nueva: **464 — una prueba que sólo cubre el caso de reposo no vale.
Antes de entregar, sesión larga con entradas aleatorias y verificación
automática de la invariante en cada evento.**

## Qué falló en el parche

La v8 decidía la orientación con `+$05` bit `$20`. Medí ese byte **en reposo**
(`63` derecha / `43` izquierda) y concluí que el bit `$20` era el volteo.
**Coincidencia.** En juego real `+$05` toma valores `4C, 4E, 54, 5A, 74, C4`…
y su bit `$20` no tiene relación con hacia dónde miras:

```
  +27  +43  +05  -> 1E
   40   40   4C  -> 00  MAL    0x4C & 0x20 = 0 -> "izquierda" (falso)
   10   10   4E  -> 01  MAL
   10   10   74  -> 00  OK     0x74 & 0x20 = $20 -> "derecha" (acierta por azar)
   10   10   C4  -> 01  MAL
```

Mi `EORA #$01` se aplicaba **al azar**. De ahí «unas veces puño y otras coz».

Es la norma 441 otra vez (dato leído en una sola situación = hipótesis), y no
la apliqué.

## ⭐ La orientación real, hallada por BARRIDO en vez de por intuición

`tools/buscaorient.py` prueba **los 8 bits de los 95 bytes** del bloque contra
la verdad de pantalla (bit `$80` del código de sprite `+$02`), sobre 2500
muestras de juego variado:

```
muestras=2500   derecha=1271   izquierda=1229

  +$03 bit7 ($80)  100.0%  directo
  +$02 bit7 ($80)  100.0%  directo
   ...ningún otro llega al 99%
```

**`+$03` bit 7 es la orientación, al 100%.** Es el byte que descarté en la v3
por ser «una salida». Lo era, pero eso sólo importaba cuando el parche
escribía la ENTRADA. La v9 no toca la entrada: sólo lee `+$03` para reescribir
la acción, así que no hay realimentación.

Y verifiqué la objeción pendiente: **en el instante del gancho `+$03` ya vale
la orientación buena**, no la del frame anterior. Medido copiándolo a `+$28`
desde el propio gancho y comparando con el valor al final del frame.

## ⭐ v9

Igual que la v8 pero leyendo `+$03` en vez de `+$05`:

```
orient: E6 88 03    LDB $03,X
        2A 02       BPL sal        ; mira a la derecha -> nada
        88 01       EORA #$01      ; a la izquierda el juego ya cruza
sal:    ...
```

### Verificación

```
prueba de estrés, 20 sesiones de 3000 frames, 187 golpes:
    VIOLACIONES = 0        (la v8 fallaba en el 54% de los golpes)

mantener el ataque y girar:  acción constante, cero flancos falsos
combo x3 en los 4 casos:     constante
ataque en el aire:           acción $02, IDÉNTICO al original
volteo en el aire:           IDÉNTICO al original (es de fábrica)
atracción:                   idéntica hasta el frame 1000
```

Sobre el volteo en el aire: medido frame a frame, la v9 y el original dan
**exactamente la misma secuencia** de volteos. El giro que ve David al saltar
y patear es comportamiento original, no lo introduce el parche. El ataque
aéreo usa la acción `$02` (salto), que mi gancho **no toca**.

```
roms/v9/ddragon2.zip   MD5 4a17fa9114ddfe808de1eb530ba161b6
```

---

# v17 — botones invertidos + el aire

## Tierra: invertido según lo pedido

David: «puño y patada ahora son consistentes, pero el orden no es el
correcto. Están invertidos.»

Cambiado en el gancho `$FBD0`: **Fire1 = COZ, Fire3 = PUÑO**. Actualizado
también el criterio de `tools/estres.py`. 8 sesiones, 72 golpes, **0 fallos**.

## ⭐ El mecanismo del aire, medido y verificado por control

```
$97B2  LDA $43,X / ANDA #$50   ¿hay ataque?  no -> salto limpio
$97B9  LDD 15,X                velocidad X
$97BB  BEQ $97CF               PARADO -> ataca
$97BD  BPL $97C8
$97BF    rama IZQUIERDA: sólo vale el bit $10   <- con el otro NO PASA NADA
$97C8    rama DERECHA:   sólo vale el bit $40   <- con el otro NO PASA NADA
$97D7  LDB #$80 / STB 3,X      el bit $10 TE DA LA VUELTA en el aire
$9832  CMPA #$19               el huracán exige que YA haya patada voladora
$983A  LDA $21,X               ...
$983F  LDA $11,X / BMI         ...y velocidad vertical en la cúspide
$9865  LDY #$98D5              TABLA DEL HURACÁN (68 69 6A 6B)
```

Esto explica **exactamente** lo que describió David: «el puño lo hace para un
lado y la patada para el otro», «en la dirección opuesta no ocurre nada»,
«en la cúspide sale el huracán con ambos botones», «se da la vuelta en el aire».

Controles que lo confirman:
- `RTS` en `$97B2` -> **desaparece todo ataque aéreo**. Es la ruta buena.
  (En su día la descarté con los `.state` muertos: aquel veredicto no valía.)
- Tocar `$98D5` (`68`->`30`) -> cambia el sprite del huracán en pantalla.

**El huracán no es un ataque independiente: es una CONTINUACIÓN de la patada
voladora** cuando se alcanza la cúspide. Por eso no basta con «asignarlo a un
botón».

## Lo conseguido en la v17

```
$97B2  cabecera nueva: ambos botones pueden atacar, sin depender de la
       dirección ni de la velocidad
$97D9  el STB 3,X ya no fuerza el volteo (JSR a $FD18)
$983A  filtro: el huracán exige que el botón recordado sea Fire1
```

Medido, barrido de retardo 4/8/14/18/24, los cuatro casos:

```
              ret 4-8      ret 14
DER Fire1     19 voladora  68 HURACÁN
DER Fire3     19 voladora  19 voladora   <- nunca huracán
IZQ Fire1     99 voladora  E8 HURACÁN
IZQ Fire3     99 voladora  99 voladora   <- nunca huracán
```

**Volteo en el aire:**

```
              original   v17
DER Fire1     1 volteo   0
DER Fire3     0          0
IZQ Fire1     0          0
IZQ Fire3     1 volteo   0
```

Resuelto: ya no se da la vuelta en el aire, y la patada sale hacia donde
miras en los dos sentidos.

## [PENDIENTE] Fire1 sigue sacando patada voladora

Falta la mitad de lo que pidió David: que con Fire1 **no** salga la voladora,
sólo el salto limpio (y el huracán si se pulsa en la cúspide).

Dos intentos, **los dos rompieron el juego** y quedan descartados:

- **v15**: gancho en `$9817` (`LDA A,Y` + `ORA 3,X`) para convertir el sprite
  `$19` en `$18`. Resultado: sprite `00` permanente, juego roto.
- **v16**: gancho en `$9813` (`LDY #$9888`) para servir una tabla alternativa
  sin patada. Resultado: el salto se queda en el sprite de reposo.

En ambos casos el problema es que esa zona no es sólo «elegir un sprite»:
el índice de animación y el temporizador se calculan alrededor y al
desviarlos se descuadra la secuencia entera.

Norma nueva: **465 — antes de sustituir una instrucción por un JSR, comprobar
que no es destino de un salto y que los registros que deja vivos se siguen
respetando. `$97CF` y `$9813` son destinos de ramas internas.**

```
roms/v17/ddragon2.zip   MD5 ba607ad795b1851c03a0b1493f1be955
```

---

# ⭐ v19 — huracán al puño, y los simultáneos arreglados

## Los movimientos simultáneos (salto + ataque a la vez)

David: «el codazo lo da con salto + patada mirando a la derecha, y el salto
patada a ras de suelo con salto + puño; si miras a la izquierda se invierten».

Medido en el ORIGINAL, y coincide exactamente:

```
DER  A+Fire1  ->  acción 05   sprites 1C 1D      patada a ras de suelo
DER  A+Fire3  ->  acción 06   sprites 75..78     CODAZO
IZQ  A+Fire1  ->  acción 06   sprites F5..F8     CODAZO      (invertido)
IZQ  A+Fire3  ->  acción 05   sprites 9C 9D      patada a ras (invertido)
```

**Buena noticia:** son las acciones `05` y `06`, que pasan por el **mismo**
despachador `$9640` y la **misma** escritura `$8F2C` que el puño y la coz. No
hacía falta buscar nada nuevo: bastaba con ampliar el filtro del gancho, que
sólo miraba las acciones 0 y 1 (`CMPA #$02`).

## [ERROR PROPIO] El EOR de la inversión

Primer intento (v18): base + bit de botón, y luego `EORA #$01` si mira a la
izquierda. Para el par 0/1 vale, pero **para el par 5/6 hace falta `EOR #$03`**
(`5=101`, `6=110`, difieren en dos bits). Con `#$01` salía `5^1 = 4`, una
acción que no es ninguna de las dos: sprite `6E`, un movimiento ajeno.

Arreglo: **invertir el BOTÓN** (`EORA #$50` sobre `+$27`) antes de elegir, en
vez de invertir la acción después. Así vale igual para los dos pares.

## El huracán, movido al puño

En la v17 el filtro exigía el bit `$10`. Con Fire1 = COZ, eso lo dejaba en la
patada, que es lo que veía David. Cambiado a `$40` (Fire3 = PUÑO).

Y para que el puño **no** saque patada voladora pero **sí** el huracán:
el huracán exige llegar al sprite `$19` (voladora en curso), así que la
cabecera del aire deja pasar a Fire3 **sólo dentro de la ventana de la
cúspide**. Ventana medida:

```
+$11 (velocidad vertical) durante el salto:
   F9 ... 08 08 07 07 06 06 05 05 04 04 03 03 02 02 01 01 00 00 FF FF ...
                                    \_____ventana [02..04]_____/
```

Fuera de esa ventana, Fire3 no ataca en el aire: salto limpio.

## Verificación de la v19

```
TIERRA (reposo, los 4 casos)
  DER Fire1 -> 01 coz     DER Fire3 -> 00 puño
  IZQ Fire1 -> 01 coz     IZQ Fire3 -> 00 puño
  estrés: 6 sesiones, 45 golpes, 0 violaciones

SIMULTÁNEOS (salto + ataque a la vez)
  DER A+Fire1 -> 75..78 CODAZO        IZQ A+Fire1 -> F5..F8 CODAZO
  DER A+Fire3 -> 1C 1D  patada ras    IZQ A+Fire3 -> 9C 9D  patada ras
  Mismo movimiento por botón en los dos lados.

AIRE (barrido de retardo 4/8/14/18/22)
             ret 4-8        ret 14 (cúspide)      ret 18-22
  Fire1      19/99 voladora  19/99 voladora        nada
  Fire3      nada            68/E8 HURACÁN         nada

VOLTEO   0 volteos en los 4 casos (el original tenía 2)
```

```
roms/v19/ddragon2.zip   MD5 7f943d281909ec8e2b7c06524699129f
```

---

# ⭐ v23 — la ventana de las combinaciones: UN BYTE

David: «las combinaciones de dos botones necesitan demasiada precisión. En el
Double Dragon 1 no hacía falta pulsar los dos botones en el mismo milisegundo».

## El juego YA TENÍA un buffer de entrada

`$8E89`, encontrado siguiendo quién lee `+$40`:

```
8E89  LDA  $40,X       flanco de este frame
8E8C  ORA  $51,X       lo ACUMULA en +$51
8E8F  STA  $51,X
8E92  INC  $53,X       contador de frames
8E95  LDA  $53,X
8E98  CMPA #$03        <-- LA VENTANA: 3 FRAMES
8E9A  LBCS $8F26       aún no -> seguir acumulando
8E9E  CLR  $53,X       pasados los 3, evaluar lo acumulado
8EA1  LDA  $51,X
```

No hay que inventar nada: **es la constante del `CMPA #$03`**, un byte en
`0x0E99`.

## [ERROR PROPIO] Dos intentos por el camino equivocado

Antes de encontrarlo probé a fabricar un "eco" de la entrada:

- **v20/v21**: eco del NIVEL (`+$43`). No sólo no funcionó: es
  **contraproducente**. El flanco se calcula como
  `(nivel_nuevo XOR nivel_viejo) AND nivel_nuevo`; al mantener el nivel alto
  artificialmente, el XOR da 0 y **se impide** el flanco.
- **v22**: eco del FLANCO (`+$40`) enganchando en `$8B7F`. El gancho se
  ejecutaba (verificado con un control que forzaba `$03`), pero tampoco
  cambiaba la ventana, porque el acumulador real está más adelante, en `+$51`.

Lo que lo resolvió fue **trazar los bytes frame a frame** con
`tools/trazacomb.py`:

```
desfase 0:   frame 5 -> +$40 = 03  (los DOS flancos en el mismo frame) -> acción 05
desfase +2:  frame 5 -> +$40 = 02  (sólo salto)  -> acción 02
             frame 7 -> +$40 = 01  (sólo Fire1)  -> tarde
```

Norma nueva: **466 — antes de fabricar un mecanismo, comprobar si el juego ya
lo tiene. Este ya traía buffer de entrada; sólo había que ampliar la
constante.**

## Barrido del valor

```
valor   ventana resultante
  3     [-2,+0]   3 frames   (original)
  4     [-2,+1]   4 frames   <-- ELEGIDO
  5     se rompe: no sale la combinación en ningún desfase
  6     [+0,+3]   se descoloca: deja de salir con desfase negativo
```

Con 5 y 6 el contador se desincroniza con el ritmo al que el juego consume el
buffer, así que **4 es el único valor que amplía sin romper**. Da un frame
más de margen (+33%).

## Verificación de la v23

```
ventana:      4 frames en los 4 casos (antes 3)
tierra:       6 sesiones, 53 golpes, 0 violaciones
golpes:       Fire1 coz / Fire3 puño, ambos lados
simultáneos:  Fire1 codazo / Fire3 patada a ras, ambos lados
aire:         Fire1 voladora · Fire3 sólo huracán en la cúspide
volteo:       0 volteos en los 4 casos
```

```
roms/v23/ddragon2.zip   MD5 9cf41fd56c055f20dbd527bca83ad89d
```

---

# ⭐ v29 — armas y la ventana revisada

## [ERROR PROPIO] Mi medida de «5 se rompe» era un ARTEFACTO

David pidió probar un frame más. Al hacerlo bien descubrí que mi barrido
anterior estaba mal: **arrancaba siempre en el mismo frame absoluto**, así
que la fase del contador `+$53` quedaba fija y el resultado dependía de ella.

`tools/ventana2.py` barre **desfase × fase** (5 fases × 11 desfases):

```
        aciertos por desfase (-5..+5)          TOTAL
N=3     0 0 0 2 3 5 3 2 0 0 0                  15/55   (original)
N=4     0 0 1 3 4 5 4 2 1 0 0                  20/55   <-- ÓPTIMO
N=5     0 0 1 2 3 4 3 2 1 0 0                  16/55
N=6     0 0 1 2 3 4 3 2 1 0 0                  16/55
```

**4 es el máximo real**: con 5 y 6 la tolerancia BAJA. El contador se
desincroniza con el ritmo al que el juego vacía el buffer. Se queda en 4.

Norma nueva: **467 — al medir tolerancias temporales, barrer también la FASE
de inicio. Un barrido de fase fija mide la fase, no la tolerancia.**

## ⭐ Las armas: el mismo patrón, tres pares más

`+$21` = tipo de arma. Selecciona la rutina vía la tabla de saltos `$8F3D`,
y las rutinas `$8F74`, `$8F9E` y `$8FAF` **empiezan todas con `LDA 3,X / BPL`**:
deciden por orientación, igual que en tierra.

Medido en el ORIGINAL (salto + ataque a la vez):

```
arma 1   DER A+Fire1 -> 0D giro    DER A+Fire3 -> 06 codazo
         IZQ A+Fire1 -> 06 codazo  IZQ A+Fire3 -> 0D giro
arma 2   DER 0F / 0E               IZQ 0E / 0F
arma 3   DER 11 / 10               IZQ 10 / 11
```

Pares completos del juego: **(00,01) (05,06) (0D,06) (0F,0E) (11,10)**

## La solución: tabla de sustitución

En vez de encadenar comparaciones (86 bytes, no cabían en el hueco de 78),
una **tabla indexada por la acción**: si mira a la izquierda, se sustituye la
acción por su pareja.

```
FBB2  TST  $03,X        ¿mira a la izquierda?
      BPL  fin          no -> nada
      CMPA #$12         acción fuera de rango -> nada
      BCC  fin
      TST  $21,X        ¿lleva arma?
      BEQ  normal
      CMPA #$06 -> $0D  ; el par (0D,06) sólo existe con arma
      CMPA #$0D -> $06
normal: LDU #$FBE8      tabla de 18 bytes
      LEAU B,U
      LDA  ,U
fin:  STA  $1E,X
```

51 bytes + 18 de tabla, dentro del hueco de `$FBB2`.

## [ERROR PROPIO] Tres intentos rotos por el camino

- **v24**: puse la tabla en `$FE60`. **No está libre**: contiene código real
  (`9D 7E A7 17...`). Lo machaqué y el juego dejó de funcionar.
- **v25**: la moví a `$FE02` pero seguí usando búsqueda con `U` y salió basura.
- **v28**: dos tablas de 18 bytes; la segunda se salía del hueco (`$FBF2+18`
  pasa de `$FBFF`). Juego roto otra vez.

Norma nueva: **468 — antes de escribir en un hueco, verificar que es `FF` en
TODO el rango que se va a ocupar, y comprobar que el final cabe.**

## Verificación de la v29

```
tierra:       6 sesiones, 49 golpes, 0 violaciones
golpes:       Fire1 coz / Fire3 puño, ambos lados
simultáneos:  Fire1 patada ras / Fire3 codazo, ambos lados
ARMAS 1,2,3:  Fire1 = giro con arma · Fire3 = codazo, EN AMBOS LADOS
aire:         Fire1 voladora · Fire3 huracán en la cúspide (idéntico a v23)
volteo:       0 volteos
ventana:      4 frames (20/55, máximo alcanzable)
```

```
roms/v29/ddragon2.zip   MD5 6c32d83f027236434a2440ed951bd2e0
```

---

# v33 — el giro con arma al puño

David: «el giro con golpeo de arma funciona a la perfección, pero con salto +
patada. Tendría que ser con salto más puño.»

## Lo medido

Con un gancho espía en `$8F2C` que copia la acción entrante:

```
arma=1  DER A+Fire1 -> 06 codazo    DER A+Fire3 -> 0D GIRO
        IZQ A+Fire1 -> 06 codazo    IZQ A+Fire3 -> 0D GIRO
```

Ya era coherente por botón en los dos lados; simplemente estaba en el botón
equivocado. Bastaba con intercambiar el par `(0D,06)`.

## La solución: dos tablas

El par del arma se comporta al revés que los demás, así que no vale una sola
tabla. Dos tablas de 18 bytes en el hueco de `$FBB2`:

```
rutina  $FBB2..$FBD7   (38 B)
TABA    $FBDA..$FBEB   sin arma
TABB    $FBEC..$FBFD   con arma (el par 0D<->06 cruzado al revés)
```

La rutina elige tabla con `TST $21,X`.

## [ERROR PROPIO] Cuatro intentos rotos

- **v30**: 60 bytes, la rutina pisaba la tabla. **La aserción lo detectó
  antes de generar la ROM** — por eso ahora todos los constructores llevan
  `assert` de solapamiento.
- **v31**: usé `EORB #$80` sobre el flip para invertir la condición del par
  del arma. Descuadraba los otros pares.
- **v32**: traté el par del arma antes de la tabla; los dos tratamientos se
  pisaban y a la izquierda salía invertido.
- **v33**: dos tablas. Correcto.

Norma nueva: **469 — todo constructor debe llevar `assert` de que el código
no invade la tabla y de que la tabla no se sale del hueco. Me ha ahorrado
generar al menos dos ROMs rotas.**

## Verificación

```
armas 1,2,3:  Fire1 = GIRO · Fire3 = codazo, EN AMBOS LADOS
tierra:       5 sesiones, 40 golpes, 0 violaciones
simultáneos:  Fire1 patada ras / Fire3 codazo, ambos lados
volteo:       0 volteos
```

```
roms/v33/ddragon2.zip   MD5 f9922170ac78d8baa46ece2929250aa7
```

---

# v40 — la SEGUNDA pasada direccional, y mi error en los simultáneos

## [ERROR PROPIO] Invertí el codazo al cambiar de método

Al pasar de la lógica «base + bit» (v23) a la «tabla de sustitución» (v33)
invertí el par sin darme cuenta. Comparación directa:

```
              v23 (aprobada)   v33 (mala)
DER Fire1      75 CODAZO        1C patada ras
DER Fire3      1C ras           75 CODAZO
```

Verificado en pantalla cuál es cuál: `75..78`/`F5..F8` = **codazo**,
`1C 1D`/`9C 9D` = **patada a ras del suelo**.

## ⭐ [HECHO] `$8F74`: la segunda pasada que me faltaba

El bug del giro con arma sin saltar tiene una causa concreta. Con un gancho
espía que **sólo copia** la acción entrante:

```
LEFT  Fire3 : entra 0C -> sale 01     <- alguien lo cambia DESPUÉS
RIGHT Fire3 : entra 0C -> sale 0C
LEFT  Fire1 : entra 01 -> sale 0C
```

Hay una **segunda** rutina direccional, posterior a `$8F2C`:

```
8F74  LDA 3,X          orientación
8F76  BPL $8F88
      --- rama IZQUIERDA ---
8F7B  CMPA #$01 -> $8FCF (LDA #$0C)    01 -> 0C  GIRO
8F7F  CMPA #$08 -> $8FCF               08 -> 0C
8F83  CMPA #$0C -> $8F94
      --- rama DERECHA ---
8F8B  CMPA #$06 -> $8FDF (LDA #$0D)    06 -> 0D
8F8F  CMPA #$0D -> $8FD7 (LDA #$06)    0D -> 06
```

Por eso anular el `0C` en `$8F2C` no servía: el juego lo volvía a poner.

Control: `RTS` en `$8F74` sobre la ROM original deja la acción coherente por
botón en ambos lados. **Es la ruta buena.**

Norma nueva: **470 — cuando un valor «vuelve» tras corregirlo, poner un
gancho espía que sólo COPIE la entrada y comparar con la salida. Si difieren,
hay un segundo escritor.**

## La solución (v40)

```
$8F74  -> RTS            neutraliza la segunda pasada direccional
$8F2C  -> gancho: decide TODO por botón, con compensación de lado
```

El gancho calcula `B = 0` (Fire1/patada) o `B = 1` (Fire3/puño), lo invierte
si mira a la izquierda (para compensar un tercer cruce que sigue vivo) y
mapea los tres pares:

```
acción 0/1    -> Fire1 = coz(1)        Fire3 = puño(0)
acción 5/6    -> Fire1 = ras(5)        Fire3 = CODAZO(6)
acción 0C/0E  -> siempre golpe normal(1): el GIRO en tierra queda ANULADO
```

El giro con arma sólo sale ya con salto + puño, que es lo que pidió David.

## Verificación de la v40

```
tierra:       5 sesiones, 47 golpes, 0 violaciones
              Fire1 = coz · Fire3 = puño, ambos lados
simultáneos:  Fire1 = 1C/9C patada al ras · Fire3 = 75/F5 CODAZO, ambos lados
arma tierra:  NUNCA sale el 0C (giro). Golpe normal con los dos botones
aire:         Fire1 voladora · Fire3 huracán en la cúspide (68/E8)
volteo:       0 volteos en los 4 casos
ventana:      4 frames
```

```
roms/v40/ddragon2.zip   MD5 67621ea017d60ab99b5a4a00a5242256
```

---

# v44 — el bug del salto, y la TERCERA pasada direccional

## [ERROR PROPIO] Un rango se comía el salto

David: *«cuando pulsamos el puño, parece anularse el salto. Después de
pulsar el puño, el salto realiza codazo o salto con patada al ras»*.

Mi rutina v40 usaba **rangos** en vez de comparaciones exactas:

```
g56:  CMPA #$07
      BCC  garma      ; A < 7  -> par 5/6
```

`A < 7` captura las acciones **2, 3, 4**, 5 y 6. Y la **acción 2 es el
SALTO**. Cada vez que el juego pedía saltar, yo lo reescribía como codazo o
patada al ras.

Y sólo pasaba *después* de atacar porque mi gancho guardaba el botón en
`+$27` y **nunca lo borraba**: con `+$27 = 0` la rutina salía sin tocar nada,
pero en cuanto pulsabas un ataque el byte quedaba marcado para siempre.

Dos fallos en una rutina de 60 bytes:

```
1. rangos (BCC) en vez de CMPA exactos -> capturaba acciones ajenas
2. +$27 no se limpiaba nunca
```

Arreglo: `ANDA #$50 / STA $27,X` sin condición (guarda el botón **o cero**),
y `CMPA` exacto para cada acción que quiero tocar.

Norma nueva: **473 — en un despachador, comparar acciones con `CMPA`
exactos. Un rango captura acciones que ni sabías que existían.**

## ⭐ [HECHO] `$8F4D`: la TERCERA pasada direccional

Con `$8F74` anulada seguía habiendo cruce a la izquierda. Lo cacé con la
prueba más simple posible: **forzar un valor fijo** en `$8F2C` y ver qué sale.

```
fuerzo 1E=00   RIGHT -> sale 00   (sprites 12 13, puño)
fuerzo 1E=00   LEFT  -> sale 01   (sprites F3 F4, coz)   <-- CRUZADO
```

Si escribo una constante y sale otra cosa, hay alguien detrás. Y lo hay:

```
$8F4D  LDA 3,X          orientación
$8F4F  BPL $8F65
       --- rama IZQUIERDA ---
$8F54  CMPA #$01 -> $8FBF     $8F58  CMPA #$08 -> $8FC3
$8F5C  CMPA #$00 -> $8FC7     $8F60  CMPA #$07 -> $8FCB
       --- rama DERECHA ($8F65) ---
$8F68  CMPA #$06 -> $8FDB     $8F6E  CMPA #$05 -> $8FD7
```

Es hermana de `$8F74`: la tabla de saltos `$8F3D` elige una u otra según
`+$21` (tipo de arma). `$8F4D` para **sin arma**, `$8F74` para **con arma**.
Por eso el arma salía bien y la tierra no.

Control: `RTS` en `$8F4D` y el valor forzado se respeta en los dos lados.

Norma nueva: **474 — para saber si algo reescribe tu valor, escribe una
CONSTANTE y compárala con lo que sale. Es más rápido que trazar.**

## La v44

```
$8F4D -> RTS     3ª pasada direccional (sin arma)
$8F74 -> RTS     2ª pasada direccional (con arma)
$8F2C -> gancho  decide TODO por el botón físico, sin mirar la orientación
$8B71 -> gancho  guarda el botón en +$27, y lo BORRA cuando no hay ninguno
```

Medido: `+$27` vale igual en los dos lados, así que **no hace falta
compensar el lado**. Mi v42 metía un `EORB #$50` que *introducía* el cruce
en vez de quitarlo.

### El giro con arma: opción 2 de David

> «este movimiento debe obedecer únicamente a la patada mirando hacia
> cualquier dirección»

```
arma  Fire1 (patada) -> 0C  GIRO con arma      en los dos lados
      Fire3 (puño)   -> 01  golpe normal       en los dos lados
```

## Verificación de la v44

```
tierra        Fire1 = coz (73/F3) · Fire3 = puño (12/92), ambos lados
simultáneos   Fire1 = patada ras (1C/9C) · Fire3 = CODAZO (75/F5), ambos lados
arma          Fire1 = GIRO (0C) · Fire3 = golpe normal (01), ambos lados
salto         acción 02 antes y después de atacar, en los dos lados
aire          Fire1 voladora · Fire3 huracán en la cúspide (68/E8)
volteo        0 volteos
estrés        5 sesiones, 40 golpes, 0 violaciones
ventana       4 frames (20/55)
```

```
roms/v44/ddragon2.zip   MD5 a1e94e6777bcd233e97f2f9eae5b2bed
```

---

# [ERROR PROPIO GRAVE] Todas mis medidas con armas eran FALSAS

David: *«con el arma, seguimos dándonos la vuelta con puño o patada en
función de hacia dónde miremos»* — justo lo contrario de lo que decían mis
verificaciones de las v33, v40, v42, v43 y v44.

## La causa

`tools/conarma.py` y `tools/armatierra.py` hacían esto:

```python
st = bytearray(f.state())
st[BASE+0x21] = arma        # <-- inyecto el tipo de arma A MANO
f.load_state(bytes(st))
```

Eso pone el **byte** del arma, pero no crea el objeto ni el enlace del
jugador con él (`+$3C`, que el código lee con `LDY $3C,X`). Es una situación
que el juego no puede producir. **Sobre esa base "verifiqué" cinco ROMs.**

Norma nueva: **475 — no inyectar estado a mano para simular una situación de
juego. Si el juego no la produce por sí mismo, la medida no vale.**

## [HECHO] Cómo se consigue un arma DE VERDAD

```
$A183  LDA $17,Y        tipo del objeto cogido
$A186  LDY #$A190       tabla de traducción
$A18A  LDA A,Y
$A18C  STA $21,X        +$21 = arma en la mano (0..7)

tabla $A190:  03 00 00 06 05 04 01 02
```

Parcheando `$A18A` (`LDA A,Y` -> `LDA #tipo`) el jugador coge el arma que yo
quiera **por el flujo normal del juego**: objeto real, enlace real.
Verificado: `+$21 = 01` estable tras coger un objeto en el nivel 1.

Herramienta nueva: `tools/conarma2.py` y `tools/armaya.py`.

**Sigue sin resolverse** reproducir el *ataque* con el arma sostenida: el
personaje entra en un estado (sprite `07`/`08`) que ignora los botones y el
arma se pierde a los pocos frames. Mi banco de pruebas no llega ahí.

## [HECHO] El huracán con arma: es de fábrica

David: *«el huracán no va con salto + puño cuando sostenemos el arma»*.

```
$9832  LDA 2,X / ANDA #$7F / CMPA #$19    ¿patada voladora en curso?
$9838  BNE $9884
$983A  LDA $21,X       <-- TIPO DE ARMA
$983D  BNE $985E       <-- si llevas arma, DESCARTA el huracán
```

El juego original ya condiciona el huracán a **no llevar arma**. No lo he
roto yo: es el comportamiento de Technōs. Lo que sale en su lugar (la patada
voladora normal) es la rama a la que cae el código al descartarlo.

Se puede cambiar —basta con no mirar `+$21` ahí— pero es una decisión de
diseño que le corresponde a David, no un bug.

## Estado real de la v44

```
CONFIRMADO POR DAVID     el salto ya va bien
DE FÁBRICA               el huracán no sale con arma en la mano
SIN RESOLVER             el giro con arma sigue dependiendo del lado
```

Las tres pasadas direccionales localizadas hasta ahora:

```
$8F4D   sin arma   (+$21 = 0)   -> anulada en la v44
$8F74   con arma   (+$21 = 1,4) -> anulada en la v44
$8F2C   mi gancho
```

La tabla `$8F3D` tiene **ocho** entradas y apuntan a **cuatro** rutinas
distintas: `$8F4D`, `$8F74`, `$8F9E` y `$8FAF`. Sólo he anulado dos. Las
armas que David usa pueden estar entrando por `$8F9E` o `$8FAF`, que siguen
cruzando por orientación. **Ésa es la hipótesis a medir cuando tenga un banco
de pruebas capaz de atacar con el arma en la mano.**

---

# El látigo: causa localizada, corrección SIN verificar

David: *«es en el primer nivel y con el látigo»*.

## ⭐ [HECHO] Reproducido en la ROM ORIGINAL con el látigo REAL

Conseguido el arma por el flujo del juego (`+$21 = 07`, sostenido 274
frames), sin inyectar nada:

```
DER Fire1(B) -> acción 0F   sprites B0 B1    GIRO golpeando
DER Fire3(Y) -> acción 0E   sprites 30 31    golpe normal
IZQ Fire1(B) -> acción 0E                    golpe normal    <-- CRUZADO
IZQ Fire3(Y) -> acción 0F                    GIRO golpeando  <-- CRUZADO
```

Es exactamente lo que describe David.

## La causa: el par es (0E,0F), y lo cruza `$8F9E`

Yo había supuesto que el par del arma era `(01,0C)`. **Falso.** Con el
látigo el par es `(0E,0F)`, y lo cruza una **cuarta** rutina direccional:

```
tabla $8F3D:  [0]$8F4D  [1]$8F74  [2]$8F9E  [3]$8FAF
              [4]$8F74  [5]$8FAF  [6]$8FAF  [7]$8F9E   <- látigo (+$21=07)

$8F9E  LDA 3,X / BPL $8FBE
       CMPA #$0E -> $8FE3 (LDA #$0F)
       CMPA #$0F -> $8FD3 (LDA #$0E)
```

La v44 anulaba `$8F4D` y `$8F74`, pero **no** `$8F9E` ni `$8FAF`. La
hipótesis que dejé escrita en el log era correcta.

## [ERROR PROPIO] Tres fallos de método en esta tanda

**1. Comparar ROMs con un guion aleatorio.** `latigo2.py` juega con
`random(9)` hasta conseguir el arma. Pero la trayectoria **depende de la
ROM**: si el parche cambia el comportamiento, el jugador acaba en otro sitio
y no coge la misma arma. Comparar así es circular. Aislado con la norma 448:
sólo `0x0E99` (la ventana) y el `RTS` de `$8F4D` desvían la trayectoria, y
**no porque estén rotos**, sino porque cambian el timing.

Norma nueva: **476 — no comparar ROMs con entradas aleatorias largas. Si el
parche altera el comportamiento, la trayectoria diverge y la comparación no
vale.**

**2. La v45/v46/v47 (tabla de pares) rompían el juego.** Acción `26` (basura)
y atracción congelada. Usaba `B` como registro de trabajo del bucle *y* como
portador del botón. Descartadas.

**3. La v48 no está verificada con el látigo.** Las medidas salen con el
personaje en movimiento y no son concluyentes.

## Estado

```
roms/v48/ddragon2.zip   MD5 40e7ae6808b056b182b695380063bb01
   = v44 + RTS en $8F9E + par (0E,0F) en el gancho

VERIFICADO   no-regresión idéntica a la v44
             tierra: Fire1 coz / Fire3 puño, ambos lados
             simultáneos: Fire1 patada al ras / Fire3 codazo, ambos lados
SIN VERIFICAR el comportamiento con el látigo en la mano
```

## Herramientas nuevas

```
tools/lat.py       consigue el LÁTIGO real forzando el tipo en $A18A
tools/guion.py     graba y reproduce un guion determinista
tools/guion2.py    guion corto y dirigido
```

---

# v49 — el error de etiquetado del codazo, y las armas restantes

David reporta cuatro cosas. Una es una **regresión mía por un error de
etiquetado que arrastraba desde el principio**.

## [ERROR PROPIO] Nunca comprobé qué sprite era el codazo

Etiqueté `1C 1D` como «patada al ras» y `75..78` como «codazo» **por
suposición**, sin verlo en pantalla. Lo correcto sale de cruzar lo que dijo
David la primera vez con lo que medí entonces:

> «el codazo lo da con salto + patada mirando a la derecha, y el salto patada
> a la altura del suelo con salto + puño»

En aquel momento Fire1 = patada, Fire3 = puño. Y yo había medido:

```
DER A+Fire1 -> acción 05  sprites 1C 1D
DER A+Fire3 -> acción 06  sprites 75..78
```

Luego **`05`/`1C 1D` es el CODAZO** y **`06`/`75 76` la patada al ras**.
Justo al revés de como lo tenía apuntado. Por eso al «arreglarlo» según mi
etiqueta, David vuelve a ver el codazo en la patada.

Corregido en la v49: Fire3 (puño) -> `05` codazo.

Norma nueva: **477 — no etiquetar un sprite sin verlo. Un número de sprite
sin captura que lo respalde es una hipótesis, y arrastrarla contamina todo lo
que se construya encima.**

## [HECHO] Las cuatro rutinas direccionales, y sus pares

```
tabla $8F3D (índice = +$21, tipo de arma):

  arma 0        -> $8F4D   pares (01,0C) y (00,07)
  armas 1 y 4   -> $8F74   pares (01,0C) y (06,0D)
  armas 2 y 7   -> $8F9E   par   (0E,0F)      <- LÁTIGO
  armas 3,5,6   -> $8FAF   par   (10,11)      <- probablemente el CUCHILLO
```

La v49 anula las **cuatro** y decide por botón en `$8F2C`, con los pares
`(00,01) (05,06) (0E,0F) (10,11) (01,0C)`.

## [SIN RESOLVER] Lo que no he podido medir

**1. El cuchillo.** No he conseguido sostener las armas 3, 5 ni 6: al
forzarlas con `$A18A`, `+$21` cae a `00` en el mismo frame. El par `(10,11)`
está añadido **por analogía con el látigo**, no medido.

**2. Recoger el cuchillo con puño o patada.** La recogida la hace `$A161`,
llamada desde `$9C79`, `$A139`, `$A746` y `$B132`. **No he medido cuál de las
cuatro es la del jugador ni qué botón la dispara.** No he tocado nada.

**3. El huracán con látigo.** Ya está documentado: `$983A LDA $21,X / BNE`
descarta el huracán si llevas cualquier arma. Es de fábrica. Quitarlo es
decisión de diseño.

## Estado de la v49

```
roms/v49/ddragon2.zip   MD5 ef0bc77f3ed6991df61b4fe95c043914

VERIFICADO     no-regresión idéntica a v44/v48
               tierra: Fire1 coz / Fire3 puño, ambos lados
               simultáneos: Fire3 = CODAZO (75/F5), Fire1 = ras (1C/9C)
SIN VERIFICAR  látigo (par 0E,0F, heredado de la v48 que David validó)
               cuchillo (par 10,11, añadido por analogía)
NO TOCADO      la recogida de objetos
               el huracán con arma
```

---

# v50 — el cuchillo, resuelto con el savestate de David

David mandó un savestate con el **cuchillo en la mano**, en zona segura. Eso
resolvió el bloqueo: llevaba varias tandas sin poder sostener un arma en el
emulador.

## El state SÍ carga (a diferencia de los cuatro primeros)

```
#RZIPv\x01# + zlib desde el offset 24  ->  RASTATE + MEM
datos del core en el offset 16, 18244 B
```

**Clave medida: hay que esperar ~30 frames tras cargarlo** antes de pulsar.
Con 2 frames el personaje ignora la entrada y parece que el botón no hace
nada (es la misma trampa que ya estaba documentada, y volví a caer en ella).

## [HECHO] El cuchillo es el ARMA 1, y su par es (01,0C)

Medido en la **ROM original** con el state de David:

```
+$21 = 01                          <- el cuchillo es el arma 1
Fire1 (B, patada) -> acción 01  sprite 73     COZ
Fire3 (Y, puño)   -> acción 0C  sprite 2F/30  LANZA el cuchillo
```

## [ERROR PROPIO] Tenía el par (01,0C) mal etiquetado

Lo llamaba «golpe normal / GIRO con arma». **`0C` no es un giro: es lanzar el
cuchillo.** Y como mi regla mandaba `Fire1 -> 0C`, el resultado era «la patada
lanza y el puño da la coz», exactamente lo que reportó David.

Verificado en la v49 antes de tocar nada: con B sale `0C` y con Y no sale
nada. Reproducido su síntoma al 100%.

El látigo no se ve afectado: usa el par `(0E,0F)`, que es otro.

## El arreglo

Dos bytes, en el bloque del par `(01,0C)`:

```
0x079F5  01 -> 0C     Fire3 (puño)   -> LANZA el cuchillo
0x079FB  0C -> 01     Fire1 (patada) -> coz
```

## Verificación de la v50

```
cuchillo      Y (puño)   -> 0C  LANZA          <- invertido, correcto
              B (patada) -> 01  coz
              (barrido de espera 25/32/35/50, consistente)
tierra        Fire1 coz / Fire3 puño, ambos lados
simultáneos   IDÉNTICOS a la v49 que David validó (75/1C, F5/9C)
no-regresión  idéntica a v44/v48/v49
estrés        3 sesiones, 27 golpes, 0 violaciones
diff v49->v50 exactamente 2 bytes
```

```
roms/v50/ddragon2.zip   MD5 af97354c26e301d288252c8699a5962a
```

## Sigue sin resolver

- **Recoger el cuchillo con puño o patada.** La recogida es `$A161`, llamada
  desde `$9C79`, `$A139`, `$A746` y `$B132`. No he medido cuál es la del
  jugador. No tocado.
- **El salto+patada con el látigo.** David: *«no me importa no poder hacer el
  huracán con arma, pero no debería hacer el salto con patada que ya hacemos
  con salto + patada»*. Pendiente de medir con el látigo en la mano.

---

# v51 — el salto+puño con arma: mi rutina del aire no miraba el arma

David: *«al pulsar el puño ha dado una patada... tampoco tendría que dar la
patada con el puño. Con la pierna ya lo hace correctamente»*.

## La causa, leída de mi propia rutina

`$FCD2`, la decisión del ataque aéreo que instalé:

```
LDA  $43,X
BITA #$10        ¿patada?  -> ataca SIEMPRE
BNE  si
BITA #$40        ¿puño?
BEQ  no
PSHS B
LDB  $11,X       velocidad vertical
CMPB #$05 / #$02 ¿en la ventana de la cúspide?
si:  LDA #$01    -> ATACA
no:  CLRA        -> no ataca
```

Con el puño en la cúspide devuelvo «ataca», **sin mirar si hay arma**. La
idea era que ahí saliera el huracán, pero `$983A` lo descarta cuando
`+$21 != 0`, así que el ataque que sí progresa es la **patada voladora**.

Resultado con arma: salto + puño = patada voladora. Exactamente el síntoma.

## El arreglo (v51)

Dos instrucciones en la rama del puño:

```
BITA #$40
BEQ  no
TST  $21,X       <-- NUEVO: ¿llevo arma?
BNE  no          <-- sí -> el puño NO ataca en el aire
```

Queda así:

```
CON arma     salto + puño   -> salto limpio, sin ataque
             salto + patada -> patada voladora
SIN arma     salto + puño   -> huracán en la cúspide (intacto)
             salto + patada -> patada voladora (intacto)
```

## [NOTA DE MÉTODO] El state del salto no sirve para validar esto

`Salto patada con puño.state` llega **con la patada voladora ya en curso**
(acción `02`, sprite `19` desde el frame 0, sin pulsar nada). No se puede ver
qué botón la produjo: la decisión ya está tomada. Medido: con `-`, `B` e `Y`
da lo mismo, en la original y en las parcheadas.

Lo que sí sirvió: leer mi propia rutina y comprobar que no consultaba `+$21`.

**Un state posterior al evento no sirve para juzgar el evento** (norma 455,
otra vez).

## Verificación de la v51

```
SIN arma (medido)
   huracán  Fire3 en la cúspide -> 68/E8   INTACTO
   voladora Fire1               -> 19/99   INTACTO
tierra        Fire1 coz / Fire3 puño, ambos lados
simultáneos   idénticos a v49/v50
cuchillo      Y (puño) lanza (0C), B (patada) coz (01)
no-regresión  idéntica desde la v44
estrés        3 sesiones, 27 golpes, 0 violaciones
```

```
roms/v51/ddragon2.zip   MD5 4105c9f6cd923dcb1acae85f71854c9b
```

El comportamiento **con arma en el aire** no lo he podido medir: haría falta
un state con el arma en la mano y en el SUELO, en zona segura, desde el que
poder saltar.

---

# v52 — la QUINTA pasada direccional: la recogida de objetos

David: *«cuando estoy cerca, los cojo y los levanto con el puño. Con la
patada los pateo. Pero hay momentos en los que con el puño también los
pateo»*. Y mandó un state con el tronco delante.

## [HECHO] Reproducido en la ROM ORIGINAL

Desde su state (`+$1E = 09` = acción de agarrar, `flip = 80`):

```
mantener B (patada) -> +$21 pasa a 03, sprites C7 C8   COGE el tronco
mantener Y (puño)   -> no pasa nada
```

Y su síntoma encaja: como el puño no coge, sale el ataque normal, que con
el tronco delante lo patea.

## ⭐ La causa: una quinta pasada, y en el BANCO CONMUTADO

Estaba en `26ac-0e.63`, no en la ROM fija. Por eso no la había encontrado:
**sólo había barrido `26a9-04.bin`**.

```
$C966  LDA 3,X            orientación
$C968  BPL $C977
       --- rama IZQUIERDA (off 0x064BA) ---
$C96D  BITA #$10 -> no coger
$C971  BITA #$40 -> COGER          (puño)
       --- rama DERECHA (off 0x064C7) ---
$C97A  BITA #$40 -> no coger
$C97E  BITA #$10 -> COGER          (patada)
```

O sea: **mirando a la izquierda se coge con el puño, mirando a la derecha
con la patada**. El mismo patrón direccional que el resto del juego, pero en
otro banco.

Norma nueva: **478 — barrer TODOS los ficheros de ROM, no sólo la CPU fija.
La quinta pasada direccional llevaba cinco tandas escondida en el banco
conmutado.**

## Verificado por experimento de control

Intercambiando sólo los dos `BITA` de la rama izquierda **sobre la ROM
original**:

```
antes:   B coge, Y no
después: Y coge, B no      <-- MEDIDO
```

La rama derecha no reaccionó con este state, y es correcto: el personaje
mira a la izquierda (`flip = 80`), así que esa rama no se ejecuta. La toco
igual por simetría.

## El arreglo (4 bytes en `26ac-0e.63`)

```
0x064BE  10 -> 40     rama izquierda
0x064C2  40 -> 10
0x064CB  40 -> 10     rama derecha
0x064CF  10 -> 40
```

Ahora **las dos ramas cogen con `$40` = puño**.

Herramienta nueva: `tools/build3.py`, que parchea varios ficheros del zip.
El anterior `build.py` sólo tocaba `26a9-04.bin`.

## Verificación de la v52

```
tronco        Y (puño) COGE (+$21=03, C7 C8) · B (patada) no    <- invertido
tierra        Fire1 coz / Fire3 puño, ambos lados
simultáneos   idénticos a v49/v50/v51
cuchillo      Y lanza (0C), B coz (01)
huracán       sin arma, Fire3 en la cúspide -> 68   INTACTO
no-regresión  idéntica desde la v44
estrés        3 sesiones, 27 golpes, 0 violaciones
```

```
roms/v52/ddragon2.zip   MD5 1591bb3ee0d287a2a63b8b1e4bab1c42
```

**Sin probar:** la pala. David aún no ha conseguido cazarla.

## [HECHO] El JUGADOR 2, medido (2026-09-05)

David: *«El segundo player no lo he podido probar, pero lo daremos por
bueno.»* El argumento para darlo por bueno es sólido —el código es el
mismo y los ganchos van indexados por `X`, no a dirección fija— pero un
argumento no es una medición. Se ha medido.

### Verificado en el desensamblado

Barridos los seis ganchos (`$F917`, `$F9D0`, `$FBB2`, `$FCD2`, `$FD18`,
`$FDDC`) buscando cualquier operando absoluto dentro del bloque del
jugador 1 (`$03A2..$0460`):

```
ganchos con dirección absoluta de P1: 0
```

Todo el acceso al estado del jugador es indexado: `STA $43,X`,
`LDB $27,X`, `TST $21,X`, `A7 88 1E` (`STA $1E,X`)... `X` la pone la
rutina que llama, con el bloque del jugador que toque. Por eso el
mismo código sirve para los dos.

### Verificado en ejecución

`tools/estres2p.py`: 3000 frames de entradas aleatorias por el **puerto
1**, comprobando en cada golpe que la acción corresponde al botón.

```
v52,     semillas 1-8:   56 golpes,  0 violaciones
virgen,  semillas 1-5:   33 golpes, 18 violaciones
```

**La prueba de control es lo que le da valor**: la ROM sin parchear falla
en el mismo test, así que el test discrimina de verdad y el 0 de la v52
significa algo (norma 378).

### Dos cosas que hubo que arreglar para poder medirlo

1. `fba.py` devolvía `0` para todo lo que no fuera el puerto 0: el
   jugador 2 no podía pulsar nada. Añadidos `hold2()` y `release2()`.
   El core **sí** consulta los dos puertos, comprobado con un espía.
2. Con monedas no basta para que entre el P2: hay que pulsar **su**
   START (el del puerto 1). Metiendo sólo monedas, el bloque `$0401`
   se queda a cero y el juego vuelve al título.

## [HECHO] Descripción en inglés para RomHacking.net (2026-09-05)

```
parches/README_EN.md              version larga, con tablas
parches/romhacking_submission.txt campos sueltos para el formulario
```

### [ERROR PROPIO] Describí mal el comportamiento ORIGINAL

En el primer borrador escribí que en el juego original «un botón ataca
delante y el otro detrás». **Es falso, y está medido en la entrada de la
v1** (línea 495 de este documento):

```
ORIGINAL, mirando DERECHA (flip=$00):  Fire1 = COZ hacia atrás
                                       Fire3 = PUÑO al frente
ORIGINAL, mirando IZQUIERDA (flip=$80): Fire1 = PUÑO al frente
                                       Fire3 = COZ hacia atrás
```

Los botones no son «delante/detrás»: son **izquierda/derecha de pantalla**.
Un botón golpea siempre hacia la izquierda y el otro siempre hacia la
derecha, y por eso lo que cambia al girarse es cuál de los dos es el puño.
La diferencia importa en una descripción pública: «delante y detrás» sonaría
a que el original ya era consistente y el hack sobra.

### [ERROR PROPIO] Dos documentos internos se contradecían

`MOVIMIENTOS.md` (de la v3) dice «Fire1 = puñetazos, Fire3 = coz».
`PENDIENTES.md` (v52) dice lo contrario. Resuelto leyendo el código de la
v52, que es la que se entrega:

```
$FBE2  LDA #$00 / BITB #$10 / BEQ / LDA #$01
       bit $10 = Fire1  ->  acción $01 = COZ
       sin bit         ->  acción $00 = PUÑO
```

**Fire1 = patada, Fire3 = puño.** `MOVIMIENTOS.md` describe la v3 y quedó
obsoleto; se deja como está porque es el historial de aquella versión, pero
la descripción pública sale del código actual, no de él.

### Afirmaciones verificadas antes de publicarlas

Cada cosa que dice la descripción, comprobada contra la ROM:

```
volteo aéreo      ORIGINAL $97D9: STB 3,X   (fuerza el volteo)
                  v52      $97D9: JSR $FD18 (lo sustituye)      -> cierto
huracán con arma  ORIGINAL $983A: LDA $21,X / BNE  (lo descarta) -> es DE FÁBRICA
ventana           ORIGINAL $8E98: CMPA #$03    v52: CMPA #$04    -> 3 a 4 frames
pares de armas    $F9D0 codazo($05)/ras($06) · $F9DC látigo($0E/$0F)
                  $F9E8 otras($10/$11) · $F9F4 cuchillo($0C/coz $01)
                  en los cuatro, el bit $10 (Fire1) elige el segundo valor
ficheros          18 en el zip, 2 modificados, 16 intactos, tamaños iguales
MD5               los cuatro del README coinciden con los reales
```

### Lo que la descripción NO promete

- El tronco: se dice explícitamente que no está verificado.
- El agarre, el rodillazo y el lanzamiento: se dice que no se han medido
  uno a uno.

Es preferible publicar una limitación conocida que un «funciona todo» que
alguien desmienta en el primer comentario.

## [HECHO] Entrada para el foro, en castellano (2026-09-05)

```
parches/post_foro.md          version Markdown
parches/post_foro_bbcode.txt  la misma en BBCode, para elotrolado
```

Dos formatos porque en elotrolado las tablas Markdown no se renderizan: en
BBCode van como bloques `[code]` alineados a mano.

### La tabla de verdad, medida limpia

Los intentos anteriores de medir esto en esta sesión salían sucios: el
personaje arrastraba la acción de la prueba anterior y `+$03` daba `$80`
en todos los casos. La herramienta buena ya existía —`tools/reposo.py`,
que espera a que `+$1E`, `+$02`, la posición y `+$1B` no cambien durante
20 frames seguidos— y con ella sale sin ambigüedad:

```
                        ORIGINAL              v52
DERECHA    Fire1        01 coz   spr 73/74    01 coz   spr 73/74
DERECHA    Fire3        00 puño  spr 12/13    00 puño  spr 12/13
IZQUIERDA  Fire1        00 puño  spr 92/93    01 coz   spr F3/F4   CAMBIA
IZQUIERDA  Fire3        01 coz   spr F3/F4    00 puño  spr 92/93   CAMBIA
```

`$92 = $12|$80` y `$F3 = $73|$80`: el bit 7 es el volteo, así que son los
mismos sprites mirando al otro lado. Confirma que **mirando a la derecha el
juego original ya hacía lo correcto** y lo que había que corregir era el
lado izquierdo, que es justo lo que decía la entrada de la v1.

### [ERROR PROPIO] Otra contradicción entre documentos

`HALLAZGOS.md` línea 1899 dice `A+Fire1 -> 05 sprites 1C 1D` y la línea
1948 dice `Fire3 = CODAZO (75/F5)`. Son la v44 y la v49: entre una y otra
descubrí que tenía el sprite del codazo mal etiquetado (norma 477) y lo
invertí. La segunda es la buena. Resuelto leyendo el código de la ROM que
se entrega:

```
$F9D0  LDA #$05 / BITB #$10 / BEQ / LDA #$06
       sin bit $10 (Fire3, puño) -> $05 CODAZO
       con bit $10 (Fire1, coz)  -> $06 patada al ras
```

Coincide con lo que David validó en su día. Los documentos antiguos se
dejan como están —son el historial de aquellas versiones— pero **para
cualquier texto público se lee el código de la ROM entregada, no las
notas**.

### Verificado antes de publicar

```
MD5 de los 4 ficheros              coinciden con los reales
233 y 4 bytes cambiados            medido sobre el zip
18 ficheros, 2 modificados, 16 no  medido
tamaños sin alterar                medido
estrés P1 semillas 11-13           0 violaciones
estrés P2 semillas 11-12           0 violaciones
```

El post declara explícitamente lo que NO está probado (troncos, agarre,
rodillazo, lanzamiento). Es mejor publicar una limitación conocida que un
«funciona todo» que alguien desmienta en el primer comentario.
