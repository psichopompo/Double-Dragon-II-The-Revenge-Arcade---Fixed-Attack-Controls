# Double Dragon II — lista de movimientos (de David)

Referencia para no perder nada al tocar los controles.

| Movimiento | Cómo se hace | Estado |
|---|---|---|
| Combo de puñetazos | Pulsa repetidamente el botón del sentido hacia el que miras | **v3: ahora es Fire1 siempre** |
| Patada trasera (coz) | Botón opuesto a la dirección en la que miras | **v3: ahora es Fire3 siempre** |
| Patada voladora | Salta y pulsa cualquier botón de ataque en el aire | Sin tocar. **Ver conflicto abajo** |
| Patada del huracán (Cyclone Kick) | Salta y pulsa ataque justo en el punto más alto | Sin tocar. **No reproducida aún** |
| Agarre de pelo | Acércate a un enemigo aturdido: agarra solo | **Sin medir** |
| Rodillazo a la cara | Botón de ataque FRONTAL con el enemigo agarrado | **Sin medir** |
| Lanzamiento | Botón de ataque TRASERO con el enemigo agarrado | **Sin medir** |
| Recoger armas | Encima del objeto + botón de ataque frontal | **Sin medir** |

## Ojo: «frontal» y «trasero» después del parche

Cuatro movimientos de la lista se describen como «ataque frontal» o «ataque
trasero». En la ROM original eso equivale a un botón u otro **según el lado**.
Con la v3, frontal = **Fire1** y trasero = **Fire3**, siempre, sin importar
hacia dónde mires. Es justo lo que se pidió, pero hay que verificar que el
agarre, el lanzamiento y el recoger armas siguen respondiendo.

## Conflicto abierto: los ataques aéreos

David: «el salto patada está asociado al puño con el salto, lo cual es
incoherente. Tendría que dar el salto patada con el salto y la patada. El
huracán, aunque sea un salto con patada, es más como un movimiento especial,
así que sí podríamos asociarlo al salto con puñetazo.»

Objetivo:

```
SALTO + Fire3 (patada)  ->  patada voladora
SALTO + Fire1 (puño)    ->  patada del huracán
```

### Lo medido hasta ahora

- En el aire hay **dos animaciones distintas**, una por botón. Confirmado con
  retardos de 2, 6, 10, 14, 18 y 22 frames desde el inicio del salto.
- **Ninguna de las dos depende del instante del salto.** El vértice está
  sobre el frame 22-24 (byte de altura `+$09`: sube a `$37` y baja) y pulsar
  ahí no produce una tercera animación.
- Por tanto, o el huracán no es una animación aparte en esta placa, o se
  dispara con otra condición que aún no he encontrado.

Falta: identificar en pantalla **cuál de las dos animaciones aéreas es la
voladora y cuál la del huracán**, y sólo entonces decidir si hay que
intercambiarlas. Se hace con capturas del frame de impacto, no con firmas.
