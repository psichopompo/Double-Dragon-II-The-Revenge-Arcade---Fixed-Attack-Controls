# Double Dragon II — PENDIENTES

## Entrega vigente

```
roms/v52/ddragon2.zip
   26a9-04.bin  3f5f52bd363519ca55b94293e7d58a47
   26ac-0e.63   ba36cb71f1437b947bab2b50f09234f2
```

Se regenera entera con `python3 tools/build_v52.py`, que se autoverifica.

## Qué hace

```
TIERRA         Fire1 = coz             Fire3 = puño
SALTO+ATAQUE   Fire1 = patada al ras   Fire3 = CODAZO
 (a la vez)
CUCHILLO       Fire1 = coz             Fire3 = LANZAR
LÁTIGO         Fire1 = giro            Fire3 = golpe normal
RECOGER        sólo con el puño (Fire3)
EN EL AIRE     Fire1 = patada voladora
 (tras saltar) Fire3 = huracán en la cúspide, y SÓLO sin arma
VENTANA        4 frames para las combinaciones (antes 3)
VOLTEO         no se da la vuelta en el aire (el original sí)
```

## Confirmado por David

| Qué | Estado |
|---|---|
| Puño y patada consistentes en ambos lados | OK |
| El salto ya no se anula tras atacar | OK |
| Codazo y patada al ras en su botón | OK |
| Látigo: giro con la patada, ambos lados | OK |
| Cuchillo: lanzar con el puño | OK |
| Salto + puño con arma ya no saca patada | OK |
| **Pala** | **OK** — probada 2026-09-05 |
| **Jugador 2** | **OK** — medido con estres2p.py: 56 golpes, 0 violaciones |

## Parche para compartir (2026-09-05)

```
parches/26a9-04.bin.bps   303 B   CPU principal   233 bytes cambiados
parches/26ac-0e.63.bps     40 B   banco conmutado   4 bytes cambiados
python3 tools/parchea.py ddragon2.zip
```

Verificado: los aplica Flips y dan el MD5 exacto; el zip reconstruido es
identico fichero a fichero a roms/v52/ddragon2.zip (18 de 18); arranca,
se juega y pasa estres.py con 3 semillas sin violaciones.

No hay un parche del zip entero a proposito: su MD5 depende de la
compresion (norma 479), asi que solo valdria para una compresion concreta.

## Pendiente de probar

| # | Qué | Nota |
|---|---|---|
| **DD2-TRONCO** | Recoger sólo con el puño | v52. David no ha vuelto a encontrar troncos |
| **DD2-DD1** | Versión con jugabilidad del DD1 | Aparcado |

## Lo que NO está medido

- El par `(10,11)` de las armas 3, 5 y 6 se puso **por analogía** con el
  látigo, sin medirlo. **La pala usa ese par y David la ha probado bien**
  (2026-09-05), así que la analogía era correcta — pero sigue sin medirse
  en el emulador, y las armas 3 y 5 tampoco se han visto una a una.
- El agarre, el rodillazo y el lanzamiento del enemigo agarrado.

## Las CINCO pasadas direccionales

El juego cruza las acciones según el lado en cinco sitios distintos. Las
cinco están neutralizadas o interceptadas:

```
$8F4D  26a9-04.bin  sin arma            RTS
$8F74  26a9-04.bin  armas 1 y 4         RTS
$8F9E  26a9-04.bin  armas 2 y 7 LÁTIGO  RTS
$8FAF  26a9-04.bin  armas 3, 5 y 6      RTS
$C96D  26ac-0e.63   RECOGIDA            4 bytes intercambiados
```

**La quinta estaba en el banco conmutado** y tardé cinco tandas en
encontrarla porque sólo barría la CPU fija (norma 478).

## Datos medidos

```
+$03 bit7   orientación real (100% en 2500 muestras)
+$1E        acción:  00 puño · 01 coz · 02 salto · 05 codazo · 06 ras
                     0C lanzar cuchillo · 0E/0F látigo · 10/11 otras armas
+$21        tipo de arma (0..7), índice de la tabla $8F3D
+$27        byte LIBRE, guarda el botón pulsado
+$40        flanco, dura UN frame · +$43 nivel · +$51 flancos acumulados
+$11        velocidad vertical; cúspide = [02..04]
$8E89       buffer de entrada; la ventana es el CMPA de $8E98
$9640       tabla de acciones · $A190 objeto -> arma
```

## Método (lo que me ha costado aprender)

- Verificar con `estres.py`: 0 violaciones o no se entrega.
- No inyectar estado a mano para simular una situación de juego (475).
- No comparar ROMs con guiones aleatorios largos (476).
- No etiquetar un sprite sin verlo en pantalla (477).
- Barrer TODOS los ficheros de ROM, no sólo la CPU (478).
- El MD5 del zip depende de la compresión: verificar las ROMs de dentro (479).
