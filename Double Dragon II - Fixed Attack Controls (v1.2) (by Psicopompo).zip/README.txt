Double Dragon II — v1.2 patches
================================

WHAT IT DOES
------------
Rebuilds the control system so that PUNCH and KICK are ALWAYS the same
button, whichever way Billy is facing. In the original game the two
actions swap over depending on orientation.

  Button 1 = PUNCH   Button 2 = JUMP (unchanged)   Button 3 = KICK

  ON THE GROUND   B1 = punch              B3 = kick
  JUMP+ATTACK     B1 = elbow smash        B3 = ground-level kick
  KNIFE           B1 = throw it           B3 = kick
  WHIP            B1 = normal swing       B3 = spin attack
  SHOVEL & CO.    consistent on both sides
  PICK UP         punch button only (B1), on BOTH sides
  KICK + OBJECT   kicks the box/log, never picks anything up
  IN THE AIR      B1 = cyclone kick (only without a weapon, at the apex)
                  B3 = flying kick
  WINDOW          4 frames for combinations (was 3)


WHAT'S NEW IN v1.2
------------------
The game now loads in FBNeo.

FBNeo verifies the CRC of every file in a romset and refuses to run a
game whose files have been altered. That is exactly what happened to the
two program ROMs this hack changes: FBNeo reported "Verify the following
romsets: ddragon2 / ROM with name 26a9-04.bin / ROM with name 26ac-0e.63".

v1.2 rewrites a few UNUSED padding bytes in each patched file so that its
CRC comes out identical to the original. The game now loads in FBNeo just
like the stock ROM, with no special folders, no core options and no extra
steps. MAME and FB Alpha, which are more lenient, keep working as before.

The button layout and gameplay are unchanged from v1.1.


WHAT'S NEW IN v1.1
------------------
The kick button no longer picks up ANY object.

In v1.0 the kick button still picked up WEAPONS (knife, whip and their
variants) because of a special case in the kick branch of the pick-up
routine ($64D4 in 26ac-0e.63): object types 5/6/7/0E jumped straight to
"pick up" before reaching the kick table.

Those types are the WEAPONS, per the object->weapon table $A190:
  type 6  -> weapon 1  (knife)
  type 0E -> weapon 7  (whip)
  type 5  -> weapon 4  (knife variant)
  type 7  -> weapon 2  (whip variant)

BOXES and LOGS are types 0/3/4, which do NOT go through that special case:
they are worth $16 (= kick) in the $6602 table and were already kicked
properly.

The fix (8 bytes): the four "BEQ $6507" jumps (to pick up) are replaced
with NOPs, so weapons fall through to the $6602 table, where they are
worth $0D (!= $16), i.e. do nothing. Result:

  v1.0    kick + weapon (5/6/7/0E) -> picked it up   (wrong)
  v1.1    kick + weapon             -> does nothing   (right)
          kick + box/log            -> kicks it       (unchanged)
          punch + any object        -> picks it up    (unchanged)


A NOTE ON TURNING AROUND WHILE HOLDING AN OBJECT
------------------------------------------------
When the character is carrying a weapon or a box, pressing kick makes him
turn around before attacking or throwing. This is NOT a bug: it is the
original back-kick, a reverse attack built into the game. In the first
Double Dragon the same reverse attack was performed with the elbow-smash
combination; in Double Dragon II it is simply the kick button. This
behaviour is unchanged from the original.


ALSO FIXED IN v1.0 (kept in v1.1)
---------------------------------
1. BUTTON MAPPING WAS INVERTED. The very first release had Button 1 =
   kick and Button 3 = punch. The correct arcade layout is Button 1 =
   punch, Button 2 = jump, Button 3 = kick. It was fixed by swapping the
   $10 and $40 bits in the hook that stores the input. Jump ($20) is
   untouched.

2. OBJECT PICK-UP. Boxes/weapons/logs were picked up wrong: an earlier
   release swapped the directional branches of the pick-up code so it
   ended up "kick picks up" instead of "punch picks up". In the original
   ROM the RIGHT branch was already correct and only the LEFT was
   inverted. The fix is 2 bytes: make the left branch match the right.


HOW TO APPLY
------------
The game is not a single ROM: it is 18 files inside ddragon2.zip. This
hack changes TWO of them, so there is one patch per file:

  26a9-04.bin.bps   main CPU       (button swap + everything else)
  26ac-0e.63.bps    banked ROM     (pick-up + kick no longer picks up)

  1. Open ddragon2.zip and extract 26a9-04.bin and 26ac-0e.63.
  2. Apply each .bps to its matching file with Flips or any BPS tool.
  3. Put both files back in the zip, replacing the originals.
  4. Leave the other 16 files alone.


WHY THERE IS NO SINGLE PATCH FOR THE WHOLE ZIP
----------------------------------------------
A zip file's MD5 depends on the compression level and the order of the
files: the same ROM content can produce many different zips. A patch made
against one zip would silently fail against another. The individual ROM
files are stable, so those are what get patched.


STARTING ROM
------------
  26a9-04.bin   b8ce1f29bb973601ff5f95b3073880a0
  26ac-0e.63    a459bd618ba87032fec636ee34e5adac

RESULT
------
  26a9-04.bin   66e634a78217cab840e61ffbef72ef68   (CRC32 0xf2cfc649, = original)
  26ac-0e.63    580701f52cb0f08ca6714c757fe3d2d1   (CRC32 0x57acad2c, = original)


VERIFIED
--------
- Both BPS patches apply in Flips and produce the exact MD5 above.
- The zip rebuilt from the patches is identical file-by-file to the
  released build: 18 of 18, zero differences.
- The patched files keep the SAME CRC32 as the originals, so FBNeo (which
  validates CRC) accepts the romset without the "patched" folder or any
  core option.
- The disassembly of $64D4 (kick branch) shows the four BEQ $6507 replaced
  with NOPs and the $6602 kick table intact: types 5/6/7/0E (weapons) are
  worth $0D (nothing) and 0/3/4 (boxes/logs) are worth $16 (kick).
- Stress tests: player 1, 5 seeds, 0 violations; player 2, 3 seeds,
  0 violations.
